---
name: agent-native-bootstrap
description: >-
  Bring a repository up to the agent-native standard for Claude, Codex, and
  Cursor. Use for a new repo or an existing one when the user asks to
  bootstrap agents, make a project agent-native, add ExecPlans, Beads, docs
  knowledge, grill-me, vet-reviews, or technology rules for Python, Next.js,
  or Ansible. Ask which kind of repo it is, show every planned change, and
  wait for confirmation before writing files.
---

# Agent-native bootstrap

Make the current repository match the standard in [references/checklist.md](references/checklist.md). Works for an empty repository and for one that already has code and docs.

Read [references/context-and-formats.md](references/context-and-formats.md) before writing any instruction file. Read only the technology files the repository actually uses.

## Ask before any write

Do this before `scripts/apply.py --apply` and before editing any file by hand.

1. Ask whether this is a new repository, meaning this skill has not been run here, or an existing one. If `.agent-native/config.json` exists, say that and recommend "existing". If it does not, recommend "new". Wait for the answer. Do not infer it and continue.
2. Ask only the remaining blanks: Beads prefix, fast test command, production resources that must not be touched, and technologies when detection is empty.
3. Run the preview from the skill directory (`~/.codex/skills/agent-native-bootstrap` or `~/.cursor/skills/agent-native-bootstrap`). It writes nothing:

```bash
python3 ~/.codex/skills/agent-native-bootstrap/scripts/apply.py --root "<repo-root>" --repo-kind new --prefix "<prefix>" --test-command "<command>"
```

Use `--repo-kind existing` when that was the answer (or when the repository already has application code/docs). Add `--technology` only for a stack the user named or the preview would detect.

4. **Check for conflicts with the existing codebase (mandatory before applying):** Inspect the `conflicts:` section printed by `apply.py` and check whether any rule being introduced conflicts with the repository's current state (for example: Next.js Pages Router `pages/api` vs App Router, an existing `src/screen/` or `src/components/` layout vs Feature-Sliced Design, ESLint/Prettier vs Biome, existing auth vs WebAuthn passkeys, or existing Python `dict` signatures and non-Ruff formatting). When any conflict is found, ask the user to decide how each conflict should be handled before proceeding. **Always mark the backward-compatible option as `(Recommended)`** so the existing codebase is not forced into an immediate rewrite, while new code written in the repository applies the new rules as much as possible and no more.
5. Show the user the `changes:` list, the `unchanged:` list, and any detected `conflicts:`. That list includes `CLAUDE.md`, `AGENTS.md`, `.cursor/rules/core-rules/agent-native-policy-always.mdc`, Copilot instructions, and `.cursor/rules/technologies/*.mdc`. Stop until the user confirms the change list and any conflict decisions.
6. Run the same command with `--apply` only after that confirmation.

Whether the repository is new or existing, missing agent files and Cursor rules are created and present ones are updated in place: prose outside the `agent-native-bootstrap` markers stays, the marked block is created or replaced, and a technology rule is replaced when the skill copy differs. Other existing docs (`PLANS.md`, `docs/`) are left in place when they already exist.

Refuse to run against `finrag_all` unless the user names this skill and says to refresh FinRAG.

## Technology rules

| Stack signal | Read and install |
|---|---|
| `pyproject.toml`, `requirements.txt`, `setup.py`, or `*.py` | [references/technologies/python.md](references/technologies/python.md) |
| `next.config.*` or a `next` dependency | [references/technologies/nextjs.md](references/technologies/nextjs.md) |
| `ansible.cfg`, `playbooks/`, `roles/`, or `molecule/` | [references/technologies/ansible.md](references/technologies/ansible.md) |

Those files are the full local rules, including the architecture section. Scoped Cursor rules load them by glob. `CLAUDE.md` and `AGENTS.md` only name the files. They do not paste the rules.

For Next.js, performance is not copied into those files. After confirmation, `--apply` runs:

```bash
npx --yes skills add vercel-labs/agent-skills --skill vercel-react-best-practices -a cursor -a claude-code -a codex -a github-copilot -y
```

That installs `vercel-react-best-practices` into the project for Cursor, Claude, Codex, and Copilot. When writing or reviewing React or Next.js code, read that skill and follow its eight categories in order: waterfalls, bundle size, server performance, client data fetching, re-renders, rendering, JavaScript, then advanced patterns. The local Next.js file still decides architecture, routing, modularity, and security. A performance rule does not override a ban there. Do not paste the Vercel rules into `CLAUDE.md` or `AGENTS.md`.

Add a new technology by adding one file in `references/technologies/` and one entry in `TECHNOLOGIES` inside `scripts/apply.py`. Follow [references/technologies/README.md](references/technologies/README.md).

## After install

1. Run `python3 ~/.codex/skills/agent-native-bootstrap/scripts/accept.py --root "<repo-root>"`. Fix anything it reports.
2. If the preview said the Beads tracker is missing, tell the user to run `bd init` with the chosen prefix, then `bd prime`.

## Skills this standard expects

Do not vendor these skills. The repository only grows the files they read.

- `ce-brainstorm` writes `docs/brainstorms/*-requirements.md`.
- `grill-me` reads `docs/plans/`, `docs/solutions/`, `docs/architecture/`, `docs/references/`, and `docs/critical/` before questions.
- `ce-plan` reads `PLANS.md` at the git root and writes `docs/plans/YYYY-MM-DD-NNN-<slug>-plan.md`.
- `ce-work`, `ce-code-review`, `ce-compound`, `learnings-researcher`, and `vet-reviews` read `docs/solutions/` and `.agents/skills/beads/SKILL.md`.

`learnings-researcher` always opens `docs/solutions/patterns/critical-patterns.md`.
