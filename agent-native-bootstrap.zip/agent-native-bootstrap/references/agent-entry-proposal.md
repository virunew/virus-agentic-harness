---
status: confirmed
---

# Agent entry files

The confirmation is the installer's change list. `scripts/apply.py` prints that list and writes nothing until the same command is run with `--apply`.

Whether the repository is new or existing, missing agent files are created and present ones keep the text outside `<!-- agent-native-bootstrap:start -->` and `<!-- agent-native-bootstrap:end -->` while creating or replacing the marked block so the standard stays in sync. Cursor technology rules under `.cursor/rules/technologies/` are created or replaced from the technology files. Other Cursor rules are not rewritten.

## Shared facts

Both `CLAUDE.md` and `AGENTS.md` carry the same facts. Neither file pastes a technology essay.

- WHY: three to five sentences. What the product is. One priority: speed, polish, or simplicity.
- WHAT: the stack, the directories that hold code, and pointers to `docs/critical/00-index.md`, `docs/references/agent-operating-policy.md`, `docs/architecture/planning-scope-and-modularity.md`, and `docs/references/execplans-and-adhoc-scripts.md`.
- HOW: `bd prime` at session start. The fast test command from `.agent-native/test-command`. `python3 scripts/plan_beads_link.py` after a plan edit. Live verification command and the production resources that are forbidden.
- Plans: `docs/plans/YYYY-MM-DD-NNN-<slug>-plan.md`, `Plan ID: NNN`, `Beads epic:` on the next line, one goal per plan.
- Skills to run: `grill-me` before an ExecPlan or a low-confidence architecture choice. `vet-reviews` before applying an outside review. Search `docs/solutions/` before a significant change.
- Do-not-use: the forbidden list from the installed technology files, one line each. Next.js App Router includes `getServerSideProps` and `pages/api`.
- Length: 200 lines is the target. 300 is the ceiling. Further detail is an `@` import of a `docs/` file, for Claude. Codex uses a normal relative link because it does not share that import syntax.

`AGENTS.md` adds two lines Codex needs:

- Nested `AGENTS.md` files override the parent. The concatenated size should stay under 32 KiB.
- Command permissions are `.codex/rules/default.rules`. `forbidden` beats `prompt`, which beats `allow`.

`.github/copilot-instructions.md` is a third short file: product, stack, and the phase gate (lint and the fast test command pass before the change is called done). It does not repeat the technology files.

## Existing repositories

If the file exists, `scripts/apply.py` keeps all text outside `<!-- agent-native-bootstrap:start -->` and `<!-- agent-native-bootstrap:end -->` and inserts or replaces only the marked block after the user confirms the preview list. Do not import FinRAG-specific rules into it.
