# Agent-native checklist

The installer first prints every create and update. It writes only when the same command is run with `--apply` after the user confirms that list. `CLAUDE.md`, `AGENTS.md`, Copilot instructions, and `.cursor/rules/technologies/*.mdc` are created or brought in sync. Other existing files are left as they are.

## TOC

- [Repository shape](#repository-shape)
- [Docs](#docs)
- [Plans and Beads](#plans-and-beads)
- [Hooks and rules](#hooks-and-rules)
- [Leave these out](#leave-these-out)

## Repository shape

1. One package: `docs/`, `PLANS.md`, Beads, and `scripts/plan_beads_link.py` live at the git root.
2. A monorepo: each package has its own prefix, `docs/`, and checker. Plan IDs are unique across every package `docs/plans/` tree. The installer treats the git root as one package unless the user names package roots.
3. Record the Beads prefix in `.agent-native/config.json`. Do not guess from the directory name on a later run if the file already has a prefix.

## Docs

4. `docs/critical/00-index.md` lists non-negotiable rules and points at the policy files.
5. `docs/architecture/planning-scope-and-modularity.md` is the full rule for one goal per plan, deep modules, once and only once, and file size. Entry files point at it. They do not paste it.
6. `docs/references/agent-operating-policy.md` holds test layers, live verification, and escalation, including when to run `grill-me`.
7. `docs/references/execplans-and-adhoc-scripts.md` holds plan ids, the Beads link, and `scripts/adhoc/`.
8. `docs/references/testing-structure.md` matches the fast command in `.agent-native/test-command`.
9. `docs/references/configuration-and-resources.md` lists required environment variables and says a missing one fails the process. No silent default host or database.
10. `docs/solutions/patterns/critical-patterns.md` exists and names the safe test command and the production resources that must not be touched.
11. `docs/plans/completed/`, `archive/`, `improvements/`, and `good_to_have/` exist so parked plans are not treated as unfinished.
12. `docs/brainstorms/` exists for `ce-brainstorm` requirements files.
13. Every generated policy and reference doc under `docs/` (excluding folder index `README.md` files) has a table of contents.
14. Technology files are copied only for stacks in use, under `docs/references/technologies/`. A Next.js stack also installs the project skill `vercel-react-best-practices`. Performance rules stay in that skill.

## Plans and Beads

15. `PLANS.md` at the git root contains the ExecPlan sections: Purpose / Big Picture, Progress, Surprises & Discoveries, Decision Log, Outcomes & Retrospective, Context and Orientation, Plan of Work, Concrete Steps, Validation and Acceptance, Idempotence and Recovery, Artifacts and Notes, Interfaces and Dependencies.
16. `.agents/skills/beads/SKILL.md` tells `ce-plan`, `ce-work`, and `vet-reviews` how to sync an ExecPlan to one epic. Label `plan-NNN`. `spec_id` is the plan path. Do not create a second epic. Do not block a parent with its child.
17. `scripts/plan_beads_link.py` and a unit test exist. The test covers a duplicate `Plan ID:` and a missing epic line.
18. Session hooks call `bd prime` or `bd ready` when `bd` is on `PATH`.
19. Git policy in the operating-policy doc is conservative: do not commit, push, or `bd dolt push` unless the user asks.
20. A finished plan or major feature gets a local annotated tag `plan-NNN-<slug>` or `feature-<slug>`. Do not push the tag unless asked.

## Hooks and rules

21. `.claude/settings.json` contains the SessionStart, PreToolUse, PostToolUse, and Stop hooks from `references/context-and-formats.md`. An existing settings file keeps its current hooks. New commands are added only if that command string is absent.
22. `.codex/rules/default.rules` contains the Starlark allow, prompt, and forbidden decisions.
23. `.cursor/rules/technologies/*.mdc` exists for each installed technology, with globs and `alwaysApply: false`.
24. `.gitignore` ignores secrets, local databases, and `graphify-out/`. The installer appends a marked block if those lines are absent. It does not rewrite the rest of the file.
25. There is no second tracker (`features/feature_list.json`, `progress/agent-progress.txt`, or a `TODO.md` used as the task list).

## Leave these out

Do not copy from FinRAG unless this repository has the same constraint:

- LLMware, `env_test`, Milvus, MongoDB, or a named inference port
- The Plan 023 cutoff
- A hook binary under `/Users/...`
- Financial table names, NSE symbols, or Materio component rules
- A second harness document that names a different plan folder or a different tracker
