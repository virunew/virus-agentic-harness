# Context, formats, and hooks

Read this before writing instruction files. Technology rules live in `references/technologies/`. They are not copied here.

## TOC

- [Token budget](#token-budget)
- [CLAUDE.md shape](#claudemd-shape)
- [Cursor rules](#cursor-rules)
- [AGENTS.md](#agentsmd)
- [Codex command rules](#codex-command-rules)
- [Copilot](#copilot)
- [Installed skills](#installed-skills)
- [Hooks](#hooks)
- [Docs the other skills read](#docs-the-other-skills-read)

## Token budget

1. The context window is finite (about 128K to 200K tokens depending on the model). Instructions compete with source, history, and the tool prompt.
2. A long always-on file is a tax on every turn. Twenty guidelines at 200 lines each can cost about 16,000 tokens (about 8 to 12 percent of a 128K to 200K window) before the user prompt is read. Adherence drops as that tax grows.
3. Write a rule that can be failed by a test or a linter. "Write clean code" is not a rule.
4. Put a rule in the file that loads only when that work is in front of the agent. Progressive disclosure is the default.

## CLAUDE.md shape

These constraints apply when the user has confirmed [agent-entry-proposal.md](agent-entry-proposal.md). Do not write the file before that.

5. `CLAUDE.md` is the short constitution. Target 200 lines. 300 lines is the ceiling.
6. Order it WHY, then WHAT, then HOW. WHY is three to five sentences: what the product is and whether the priority is speed, polish, or simplicity.
7. Detail lives behind `@` imports (`.claude/rules/`, `.claude/skills/`, `docs/`). Import a document when the task needs it. Do not paste it into the root file.
8. Name forbidden libraries and forbidden patterns in a short list. Example: `getServerSideProps` is forbidden when the repo is Next.js App Router.
9. Do not paste Python, Next.js, or Ansible rule essays into this file. Those load by glob.

## Cursor rules

10. Rules are `.cursor/rules/**/*.mdc`. Do not create a root `.cursorrules` file. That format is retired.
11. Frontmatter fields are `alwaysApply`, `globs`, and `description`.

| Mode | Frontmatter | When it loads |
|---|---|---|
| Always | `alwaysApply: true` | Every chat |
| Files | `globs` set, `alwaysApply: false` | Only while a matching file is in context |
| Intelligent | `description` set, no globs, `alwaysApply: false` | The agent loads it when the description matches the task |
| Manual | no frontmatter | Only when the user names the rule |

12. A React rule uses `**/*.tsx` and `**/*.jsx`. It must not load while a Python or Ansible file is the file being edited.
13. All `alwaysApply: true` rules together stay under about 2,000 tokens. Technology rules are not always-apply.
14. An intelligent rule needs a description that says when to load it. An empty description does not load.

## AGENTS.md

15. `AGENTS.md` is the tool-agnostic agent README. Codex, Cursor, Copilot, and Claude can read it.
16. Codex walks from the git root down to the working directory and concatenates each `AGENTS.md`, up to 32 KiB. The file closer to the working directory wins on conflict.
17. A nested `AGENTS.md` exists only to override a parent rule for that directory. Do not repeat the parent file.
18. Keep it as short as `CLAUDE.md`. Point at `docs/` for the long rule.

## Codex command rules

19. Command permission rules are Starlark files in `.codex/rules/` in the repo, or `~/.codex/rules/default.rules` for one machine. The installer writes the repo file only.
20. A rule returns `allow`, `prompt`, or `forbidden`.
21. When two rules match, the most restrictive wins: `forbidden`, then `prompt`, then `allow`.
22. Use `forbidden` for destructive filesystem commands. Use `prompt` for network calls that are not part of the project's named safe set. Use `allow` only for commands the user has already named as safe.

## Copilot

23. `.github/copilot-instructions.md` is the Copilot review and generation brief. It states the product, the stack, and the phase gate (tests and lint before the change is called done). It stays short. It does not restate technology essays.
24. Copilot instructions are written with `CLAUDE.md` and `AGENTS.md` after the user confirms the installer's change list.

## Installed skills

25. A Next.js repository installs `vercel-react-best-practices` from `vercel-labs/agent-skills` with `npx skills add`, into the project, for Cursor, Claude, Codex, and Copilot. That writes `skills.sh.json` and the skill under `.agents/skills/` (and `.claude/skills/` for Claude).
26. That skill is the performance rule set. This bootstrap does not copy its rules into `CLAUDE.md`, `AGENTS.md`, or `references/technologies/nextjs.md`. Those files point at it and say when it wins and when a local ban wins.

## Hooks

Hooks live in `.claude/settings.json`. A hook can be a shell command, an HTTP call, or a sub-agent. This installer uses shell commands only. Claude exposes many other lifecycle events. The installer wires SessionStart, PreToolUse, PostToolUse, and Stop, which are the ones that guard edits and verify work. The model does not format, lint, or typecheck by hand when a hook does that job.

27. `PostToolUse` after `Edit` or `Write` formats and lints the edited file.
    - Python: `ruff format`, then `ruff check --fix`.
    - TypeScript and JavaScript: `biome check --write`, then `tsc --noEmit` when `tsconfig.json` exists.
    - Ansible YAML: `yamllint`, then `ansible-lint`.
    - If the tool is not installed, the hook exits 0 and names the missing tool. It does not invent a format.
28. `PreToolUse` exit code 2 blocks the tool and returns stderr to the agent. The bundled hook blocks:
    - recursive delete and raw disk write (`rm -rf`, `mkfs`, `dd if=`)
    - `chmod -R` and mode `777`
    - writes to `.env` and `.env.*`
    - writes under `migrations/`, `alembic/versions/`, and `scripts/deploy*`
    The hook may instead return JSON `permissionDecision` of `allow`, `deny`, or `ask`. Exit 2 is the deny used here.
29. `SessionStart` prints the git branch, the last five commits, `bd prime` when Beads is installed, and `bd ready` or `gh issue list --limit 5`.
30. `Stop` runs the fast command stored in `.agent-native/test-command` when that file exists. A non-zero exit blocks the stop with code 2. Leave the file absent when the user has no fast command yet. The command is the unit or lint check, not a full browser suite.
31. Do not instruct the model to "format the code" or "make sure it is strictly typed" in place of rules 24 and 25 of the Next.js file. The hook is the enforcement.

## Docs the other skills read

32. `PLANS.md` at the git root is the ExecPlan spec. `ce-plan` stops if it cannot read one.
33. Plans are `docs/plans/YYYY-MM-DD-NNN-<slug>-plan.md`. `NNN` is unique across that tree, including `completed/` and `archive/`. The first plan is `001`. There is no "start at 023" cutoff.
34. An unfinished plan has `Plan ID: NNN` and `Beads epic: <prefix>-...` on the next line. Unfinished means the file is outside `completed/`, `archive/`, `improvements/`, and `good_to_have/`, and a Progress box is open. A plan with no boxes stays unfinished until `Status:` says complete, closed, or parked.
35. `python3 scripts/plan_beads_link.py` exits 0 only when that link holds and no `Plan ID:` repeats.
36. `docs/solutions/patterns/critical-patterns.md` exists. New learnings use `ce-compound` frontmatter: `module`, `date`, `problem_type`, `component`, `severity`. Bug write-ups also have `symptoms`, `root_cause`, and `resolution_type`.
37. One-time scripts go in `scripts/adhoc/`. Plan scripts use the plan id prefix. Durable code does not go there.
38. Graphify is optional. If `graphify-out/` exists, query it to find files, then read those files before editing. Ignore `graphify-out/` in git. Do not hardcode a home-directory path to the `graphify` binary.
