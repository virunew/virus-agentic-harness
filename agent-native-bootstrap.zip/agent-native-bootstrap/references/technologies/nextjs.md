# Next.js and React rules

Load this file only for Next.js work. Globs: `**/*.tsx`, `**/*.jsx`, `**/app/**/*.ts`, `**/pages/**/*.ts`. Do not load it while editing Python, Ansible, or other non-UI files.

App Router is the default. Next.js 15 is the assumed baseline unless the repo pins another version in `package.json`.

This file owns architecture, routing, modularity, and security. Performance is the installed Vercel skill `vercel-react-best-practices`. Use both, in the order in rule 16.

## TOC

- [Architecture](#architecture)
- [Framework boundaries](#framework-boundaries)
- [Performance](#performance)
- [Modularity](#modularity)
- [Security](#security)
- [Mechanical checks](#mechanical-checks)

## Architecture

1. One change has one outcome. Do not add a screen, dialog, cache, or fallback the task did not ask for.
2. A page or screen file composes named components and hooks. Data shaping and request logic stay in the hook or module those callers use. Do not split a file only to shorten it when the caller must then assemble the pieces.
3. A behavior several screens need lives in one hook, function, or component. Those screens call it. Do not copy the body into each screen. This does not authorize a sweep that merges unrelated copies.
4. Required configuration is explicit. A missing API base URL or auth setting fails visibly. Do not substitute a localhost URL or a default credential.
5. TypeScript is strict. Do not use `any`. Define the props interface before the component body. Prefer an interface for an object shape that may gain fields.
6. A UI bug is traced to the first bad step: request payload, response shape, hook state, provider order, render logic, CSS, or the running environment. Do not patch only the pixel that looks wrong while that step is unknown.
7. If Material UI is already the component library, import each component from its own path (`import Button from '@mui/material/Button'`) and space with the theme spacing scale. Do not add Material UI to a project that does not use it.
8. Check the narrow viewport first, then a desktop width. The change is not done when only one of those has been looked at.

## Framework boundaries

9. Components are Server Components unless they need state, effects, or browser events. Do not add `"use client"` to a layout, a page, or a route file to support one control. Put that control in a leaf client component and pass it the smallest props. A like button is a leaf; the page that renders the article stays a Server Component.
10. `"use client"` is a bundle boundary. Everything that file imports is client JavaScript. Do not place it near the root.
11. In new repositories or `app/` routes, do not use `getServerSideProps` and do not add `pages/api` routes; HTTP handlers are `app/.../route.ts` with `GET` and `POST` exports. In existing Pages Router repositories (`pages/` or `src/pages/`), existing `pages/api` routes and `getServerSideProps` remain valid until a migration is explicitly requested, while new routes follow the repository's active router.
12. Dynamic routes use `[slug]`. Catch-all routes use `[...slug]`. Parallel routes use `@folder`. Intercepting routes use the `(.)` convention. Do not invent a different file layout.
13. Do not use class components.
14. A component file stays under 200 lines. Past that, extract a child component. Do not split a file only to satisfy the number when the extract would be a pass-through wrapper.
15. In App Router forms, do not bind each keystroke to `useState` only to submit; use `<form action={serverAction}>`, read `FormData` in the Server Action, validate with Zod on the server, and render pending and error state with `useActionState`. In existing repositories that submit to an external API or Pages Router endpoint, keep the existing form pattern for existing screens and validate payloads at the boundary.

## Performance

16. Performance rules live in the project skill `vercel-react-best-practices`, installed with `npx skills add vercel-labs/agent-skills --skill vercel-react-best-practices`. Read that skill when writing, reviewing, or refactoring React or Next.js code. It holds the full rule set, grouped into eight categories. Apply them in its order: waterfalls, bundle size, server performance, client data fetching, re-renders, rendering, JavaScript, then advanced patterns. Do not start at a later category while an earlier one is still broken in the same change. Do not copy those rules into this file, `CLAUDE.md`, or `AGENTS.md`.
17. Use this file and that skill together. Rules 1–15 decide what may be built and how routes and components are shaped. The Vercel skill decides how that code performs. Rules 18–25 still apply after it. A performance rule does not override a ban in this file. Do not open a performance sweep of files the task did not touch. Inside a file you do change, write it the way the skill says.

## Modularity

18. In new repositories (or repositories already using Feature-Sliced Design), organize UI by business slice from top to bottom: App, Processes, Pages, Widgets, Features, Entities, Shared, where a file imports only from layers below it. In existing repositories with an established layout (such as `src/screen/`, `src/components/`, `src/hooks/`), preserve the existing folder boundaries for existing modules and keep new code modular with unidirectional imports (screens compose components and hooks; shared utilities do not import screens).
19. In App Router repositories, the `app/` directory defines URLs only: page files compose slices or screen components, while data loading, mutations, and feature UI live in the slices/modules, not in the route file.
20. The linter (Biome or ESLint) enforces import boundaries. The PostToolUse hook surfaces that failure. Do not disable the rule for a one-off import.

## Security

21. Do not store session tokens or JWTs in `localStorage` or `sessionStorage`. The Vercel skill may discuss versioning other client storage. That does not allow a session token there.
22. Session cookies are `httpOnly`, `secure`, and `sameSite`. They are set only in a Route Handler, API route, or Server Action.
23. When building a new authentication system from scratch, prefer passkeys (WebAuthn / FIDO2) over adding a new password store. In existing repositories that already use an authentication provider (such as NextAuth / OAuth / SSO), keep the existing authentication system and follow its session rules.

## Mechanical checks

24. Formatting and lint run in a PostToolUse hook: `biome check --write` when Biome is configured, or Prettier/ESLint in existing repositories that have not adopted Biome. The model does not hand-format.
25. The same hook runs `tsc --noEmit` when a `tsconfig.json` exists and the edited file is TypeScript. A type error stops the task.
