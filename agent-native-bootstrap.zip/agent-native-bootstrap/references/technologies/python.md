# Python rules

Load this file only for Python work. Globs: `**/*.py`.

## TOC

- [Architecture](#architecture)
- [Types](#types)
- [Lint and format](#lint-and-format)
- [Async](#async)

## Architecture

1. One change has one outcome. Do not add a feature, fallback, or second code path that the task did not ask for.
2. Keep main orchestration scripts focused (aim under ~200 lines). Place script-specific helpers in a sibling `{script_stem}_helpers/` package with `__init__.py` containing deep modules that hide internal steps behind a small public interface. Split a helper past ~500 lines only when it mixes unrelated concerns; do not split a file only to shorten it when the caller must then run those pieces in order.
3. A behavior that several paths need lives in one function. Those paths call it. Do not copy the body into each path. This does not authorize a repository-wide cleanup of old copies.
4. Required configuration is explicit. If a host, database, credential, or model endpoint is missing, fail with a clear error. Do not substitute localhost, a public endpoint, or a default database name.
5. Log with `logging.getLogger(__name__)` under `logs/` with log rotation for long-running processes. Name the operation and domain identifiers (entity, file, or batch id). INFO is a completed action or a decision that changes the outcome. WARNING is a skip or a non-fatal failure. ERROR is a failed unit of work and includes the exception and the input that caused it. Do not log secrets, connection URLs, API keys, or full document bodies.
6. A script or batch pipeline that writes data is idempotent: running it again with the same inputs does not duplicate rows or leave a partial write as the finished state.
7. Strict TDD (red -> green -> refactor) applies to features, bug fixes, and refactors: write the failing test first, then the smallest change that passes, then cleanup.
8. Fix the first bad step. A patch that only hides the visible error is temporary and is described that way.

## Types

9. Every new or modified function and method has explicit parameter types and an explicit return type. `mypy` is the checker.
10. For new domain models, service boundaries, and configuration payloads, use a `dataclass` or (when validated or serialized) a Pydantic v2 model rather than an untyped bare `dict`. In existing repositories, preserve existing route, framework, or library `dict` signatures unless the task explicitly refactors that interface; do not force an immediate rewrite of working callers.
11. When scaffolding a new project's editor or `pyproject` config, set Python analysis type checking to `strict`. In an existing codebase without strict mode, apply strict typing to new and modified code without breaking untouched modules.
12. Do not silence a type error with an untyped escape unless the line says why.

## Lint and format

13. The model does not spend output on formatting or mechanical lint. A PostToolUse hook runs `ruff check --fix` on the edited `.py` file, and runs `ruff format` when the repository configures Ruff formatting (or on newly created files) so existing repositories do not suffer noisy whole-file formatting diffs on minimal edits.
14. Ruff's pyupgrade rules (`UP`) are enabled so legacy syntax is rewritten by the tool, not by the model.
15. Do not add a second formatter beside Ruff.

## Async

16. Inside `async def`, do not call blocking I/O. Forbidden examples: `requests.get`, `requests.post`, `time.sleep`, and any other call that waits on the network or the clock without awaiting.
17. Async HTTP uses a non-blocking client (`aiohttp` or async `httpx`), not `requests`.
18. CPU-bound or synchronous blocking work (large JSON processing, cryptography, synchronous SDK calls) does not run directly inside `async def`. Offload blocking calls or GIL-releasing work with `await asyncio.to_thread(...)` (`ThreadPoolExecutor`), and offload pure-Python CPU-bound work with `ProcessPoolExecutor` and `await loop.run_in_executor(...)`.
19. These rules apply to FastAPI and to async Flask. One blocking call stalls the single event loop.
