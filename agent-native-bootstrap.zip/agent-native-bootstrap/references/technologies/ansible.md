# Ansible rules

Load this file only for Ansible work. Globs: `playbooks/**/*.{yml,yaml}`, `roles/**/*.{yml,yaml}`, `molecule/**/*.{yml,yaml}`. Do not attach these rules to every YAML file in the repo.

## TOC

- [Architecture](#architecture)
- [Lint](#lint)
- [Idempotence](#idempotence)
- [Molecule](#molecule)

## Architecture

1. One change has one outcome. Do not add a role, a second play, or a compatibility path the task did not ask for.
2. A role has a small entry point. The steps stay inside the role. Do not split a playbook only to shorten it when the caller must then run the pieces in order.
3. A task sequence several plays need lives in one role. Those plays call it. Do not copy the tasks into each play. This does not authorize a sweep that merges unrelated roles.
4. A required variable that is missing fails the play. Do not invent a default host, credential, or inventory path that hides the missing value.
5. Fix the first bad step. A `changed_when: false` that hides a real change is not a fix. Say so if a suppression is temporary.

## Lint

6. `ansible-lint` is required. A task that fails `ansible-lint` is not done.
7. Use fully qualified collection names. `shell` and `apt` are forbidden. Write `ansible.builtin.shell` and `ansible.builtin.apt`. This is `fqcn[action-core]`.
8. Quote octal file modes. `mode: 0644` is forbidden because YAML may read it as decimal `420`. Write `mode: "0644"`. This satisfies `risky-octal` and `yaml[octal-values]`.
9. Run `yamllint` and `ansible-lint` before `molecule test`.

## Idempotence

10. A playbook run twice with the same inputs does not report a change on the second run unless the machine state actually changed.
11. `ansible.builtin.command` and `ansible.builtin.shell` include a change signal: `changed_when: false`, or `creates`, or `removes`. This satisfies `no-changed-when`.
12. Prefer a module that describes the desired state over a shell script that mutates the machine.

## Molecule

13. A new role includes `molecule/default/converge.yml` and `molecule/default/verify.yml`.
14. `molecule test` is the acceptance run. Its lifecycle is dependency, create, converge, idempotence, verify, destroy, inside a disposable container (Docker or Podman).
15. Do not skip the idempotence step. A role that changes the system on every converge is unfinished.
