# Technology rule files

## TOC

- [Add a technology](#add-a-technology)
- [Rules for the rule file](#rules-for-the-rule-file)

## Add a technology

1. Add `references/technologies/<name>.md`. Use testable rules. No platitudes.
2. Register `<name>` in `TECHNOLOGIES` in `scripts/apply.py` with detect signals and Cursor globs.
3. The installer copies the file to `docs/references/technologies/<name>.md` and wraps it in `.cursor/rules/technologies/<name>.mdc`.
4. Do not copy the file into `CLAUDE.md` or `AGENTS.md`. Those files may name it in one pointer line after the user confirms the agent-entry proposal.

## Rules for the rule file

- One concern per rule. A reader can pass or fail it.
- Say the forbidden pattern and the required pattern.
- State when a hook, not the model, enforces the rule.
- Leave the file out of `alwaysApply`. Globs attach it only while matching files are in context.
