# Research coverage

Each claim from the context-engineering research maps to one file. A claim with no row is missing.

| Claim | File |
|---|---|
| Finite context, token tax, no platitudes, testable rules | `references/context-and-formats.md` rules 1–4 |
| CLAUDE.md WHY/WHAT/HOW, 200 lines, 300 ceiling, @imports, forbidden list, no getServerSideProps | `references/context-and-formats.md` rules 5–9 and `references/technologies/nextjs.md` rule 11 |
| Cursor .mdc, four activation modes, globs, 2,000-token always-apply cap, no root .cursorrules | `references/context-and-formats.md` rules 10–14 |
| AGENTS.md hierarchy, 32 KiB, closer file wins | `references/context-and-formats.md` rules 15–18 |
| Codex Starlark allow, prompt, forbidden, most restrictive wins | `references/context-and-formats.md` rules 19–22 and `templates/codex-default.rules` |
| Copilot instructions, stack, phase gate, no deprecated APIs | `references/context-and-formats.md` rule 23 |
| npx skills add, skills.sh.json, Vercel react-best-practices skill | `references/context-and-formats.md` rules 25–26 and `references/technologies/nextjs.md` rules 16–17 |
| Hooks, not the model, for format and types | `references/context-and-formats.md` rules 27–31 |
| PostToolUse Biome, Prettier named as the alternative, tsc --noEmit | `references/context-and-formats.md` rule 27 and `templates/hooks/post_tool_use.sh` |
| PreToolUse exit 2, permissionDecision, block rm -rf, disk writes, chmod, .env, deploy scripts, migrations | `references/context-and-formats.md` rule 28 and `templates/hooks/pre_tool_use.sh` |
| SessionStart branch, commits, issues | `references/context-and-formats.md` rule 29 and `templates/hooks/session_start.sh` |
| Stop hook blocks when tests were not run | `references/context-and-formats.md` rule 30 and `templates/hooks/stop_check.sh` |
| Python architecture: one outcome, deep modules, once and only once, explicit config, logging, idempotent writers, test first, root cause | `references/technologies/python.md` rules 1–8 |
| Python type hints, mypy, no bare dict, dataclass, Pydantic v2, strict checking | `references/technologies/python.md` rules 9–12 |
| Ruff format, ruff check --fix, UP pyupgrade | `references/technologies/python.md` rules 13–15 |
| No blocking I/O in async def, aiohttp over requests, ProcessPoolExecutor | `references/technologies/python.md` rules 16–19 |
| Ansible architecture: one outcome, small role, once and only once, missing vars fail, do not hide a real change | `references/technologies/ansible.md` rules 1–5 |
| Ansible-lint, FQCN, quoted octals, changed_when, Molecule lifecycle, yamllint first, converge.yml and verify.yml | `references/technologies/ansible.md` rules 6–15 |
| Next.js architecture: one outcome, composition, once and only once, explicit config, strict types, first bad UI step, direct MUI imports when MUI is already used, narrow viewport then desktop | `references/technologies/nextjs.md` rules 1–8 |
| Server Components by default, leaf client components, no root use client | `references/technologies/nextjs.md` rules 9–10 |
| No getServerSideProps, route.ts, [slug], [...slug], @folder, intercepting routes | `references/technologies/nextjs.md` rules 11–12 |
| No class components, 200-line components | `references/technologies/nextjs.md` rules 13–14 |
| Server Actions, Zod, form action, useActionState, no per-keystroke useState | `references/technologies/nextjs.md` rule 15 |
| Waterfalls, bundle size, server performance, client fetching, re-renders, rendering, JavaScript, advanced patterns, in that impact order | installed skill `vercel-react-best-practices`; `references/technologies/nextjs.md` rules 16–17 say to load it and not copy it |
| FSD layers and unidirectional imports, app/ for URLs only, linter boundary | `references/technologies/nextjs.md` rules 18–20 |
| No localStorage tokens, httpOnly secure sameSite cookies, passkeys by default | `references/technologies/nextjs.md` rules 21–23 |
| Biome covers most ESLint rules and runs in the hook | `references/technologies/nextjs.md` rules 24–25 |
