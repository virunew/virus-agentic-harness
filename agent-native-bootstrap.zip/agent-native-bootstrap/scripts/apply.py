#!/usr/bin/env python3
"""Preview or apply the agent-native standard.

The default is a dry run: it prints every create and update and writes nothing.
Pass --apply only after the user confirms that brief. Agent files and the
technology Cursor rules are created or updated. Other existing files are kept.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
from datetime import date
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parents[1]
TEMPLATES = SKILL_ROOT / "templates"
TECH_DIR = SKILL_ROOT / "references" / "technologies"

TECHNOLOGIES = {
    "python": {
        "description": "Python typing, Ruff, and non-blocking async rules. Apply when editing Python.",
        "globs": ["**/*.py"],
        "detect_names": ["pyproject.toml", "requirements.txt", "setup.py", "Pipfile"],
    },
    "nextjs": {
        "description": "Next.js App Router and React rules. Performance comes from the vercel-react-best-practices skill. Apply when editing Next.js UI or routes.",
        "globs": ["**/*.tsx", "**/*.jsx", "**/app/**/*.ts", "**/pages/**/*.ts"],
        "detect_names": ["next.config.js", "next.config.mjs", "next.config.ts"],
    },
    "ansible": {
        "description": "Ansible lint, fully qualified module names, and Molecule rules. Apply when editing playbooks or roles.",
        "globs": [
            "**/playbooks/**/*.yml",
            "**/playbooks/**/*.yaml",
            "**/roles/**/*.yml",
            "**/roles/**/*.yaml",
            "**/molecule/**/*.yml",
            "**/molecule/**/*.yaml",
        ],
        "detect_names": ["ansible.cfg"],
    },
}

DOC_FILES = [
    "docs/critical/00-index.md",
    "docs/architecture/planning-scope-and-modularity.md",
    "docs/references/agent-operating-policy.md",
    "docs/references/execplans-and-adhoc-scripts.md",
    "docs/references/testing-structure.md",
    "docs/references/configuration-and-resources.md",
    "docs/references/agent-skill-map.md",
    "docs/references/CONCEPTS.md",
    "docs/solutions/patterns/critical-patterns.md",
    "docs/plans/completed/README.md",
    "docs/plans/archive/README.md",
    "docs/plans/improvements/README.md",
    "docs/plans/good_to_have/README.md",
    "docs/brainstorms/README.md",
]

AGENT_FILES = (
    "CLAUDE.md",
    "AGENTS.md",
    ".cursor/rules/core-rules/agent-native-policy-always.mdc",
    ".github/copilot-instructions.md",
)
MARKER_START = "<!-- agent-native-bootstrap:start -->"
MARKER_END = "<!-- agent-native-bootstrap:end -->"
VERCEL_REACT_SKILL = "vercel-react-best-practices"
VERCEL_REACT_ADD = [
    "npx",
    "--yes",
    "skills",
    "add",
    "vercel-labs/agent-skills",
    "--skill",
    VERCEL_REACT_SKILL,
    "-a",
    "cursor",
    "-a",
    "claude-code",
    "-a",
    "codex",
    "-a",
    "github-copilot",
    "-y",
]
GITIGNORE_BLOCK = """
# agent-native-bootstrap
.env
.env.*
!.env.example
!.env.sample
!.env.template
*.db
*.sqlite
*.sqlite3
graphify-out/
.agent-native/last-test-ok
"""


SKIP_SCAN_DIRS = frozenset({".git", ".venv", "venv", "node_modules", ".next", "dist", "build", "vendor", ".agent-native"})


def _has_user_python_files(root: Path) -> bool:
    managed = {root / "scripts" / "plan_beads_link.py", root / "tests" / "test_plan_beads_link.py"}
    for path in root.rglob("*.py"):
        if path in managed:
            continue
        if any(part in SKIP_SCAN_DIRS for part in path.relative_to(root).parts):
            continue
        return True
    return False


def detect_technologies(root: Path) -> list[str]:
    found: list[str] = []
    for name, spec in TECHNOLOGIES.items():
        if any((root / marker).exists() for marker in spec["detect_names"]):
            found.append(name)
            continue
        if name == "python" and _has_user_python_files(root):
            found.append(name)
        elif name == "nextjs" and _package_depends_on_next(root):
            found.append(name)
        elif name == "ansible" and any((root / folder).exists() for folder in ("playbooks", "roles", "molecule")):
            found.append(name)
    return found


def _resolve_config_defaults(root: Path, prefix: str, test_command: str, forbidden: str) -> tuple[str, str, str]:
    path = root / ".agent-native" / "config.json"
    command_path = root / ".agent-native" / "test-command"
    existing: dict = {}
    if path.exists():
        try:
            existing = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            existing = {}
    resolved_prefix = prefix or str(existing.get("beads_prefix") or "")
    resolved_test = test_command or str(existing.get("test_command") or "")
    if not resolved_test and command_path.exists():
        resolved_test = command_path.read_text(encoding="utf-8").strip()
    resolved_forbidden = forbidden or str(existing.get("forbidden") or "")
    return resolved_prefix, resolved_test, resolved_forbidden


def apply(
    root: Path,
    prefix: str,
    test_command: str,
    technologies: list[str],
    forbidden: str,
    dry_run: bool,
) -> list[str]:
    report: list[str] = []
    prefix, test_command, forbidden = _resolve_config_defaults(root, prefix, test_command, forbidden)
    fallback_test = test_command or 'echo "No fast test command configured"'
    fallback_forbidden = forbidden or "None named yet. Ask before touching a production service."
    mapping = {
        "{{PREFIX}}": prefix,
        "{{TEST_COMMAND}}": fallback_test,
        "{{FORBIDDEN}}": fallback_forbidden,
        "{{DATE}}": date.today().isoformat(),
    }
    _write_config(root, prefix, test_command, forbidden, technologies, report, dry_run)
    _copy_if_absent(TEMPLATES / "PLANS.md", root / "PLANS.md", mapping, report, dry_run)
    for relative in DOC_FILES:
        _copy_if_absent(TEMPLATES / relative, root / relative, mapping, report, dry_run)
    _copy_if_absent(
        TEMPLATES / "docs" / "plans" / "completed" / "README.md",
        root / "scripts" / "adhoc" / "README.md",
        mapping,
        report,
        dry_run,
        override_text="# Adhoc scripts\n\nOne-time scripts live here. Plan scripts use `NNN-<slug>`. Durable code stays in the application tree.\n",
    )
    _copy_if_absent(TEMPLATES / "beads" / "SKILL.md", root / ".agents" / "skills" / "beads" / "SKILL.md", mapping, report, dry_run)
    _copy_if_absent(TEMPLATES / "cursor" / "beads.mdc", root / ".cursor" / "rules" / "beads.mdc", mapping, report, dry_run)
    _copy_if_absent(TEMPLATES / "cursor" / "graphify.mdc", root / ".cursor" / "rules" / "graphify.mdc", mapping, report, dry_run)
    _copy_if_absent(TEMPLATES / "plan_beads_link.py", root / "scripts" / "plan_beads_link.py", mapping, report, dry_run)
    _copy_if_absent(TEMPLATES / "test_plan_beads_link.py", root / "tests" / "test_plan_beads_link.py", mapping, report, dry_run)
    for tech in technologies:
        _install_technology(root, tech, report, dry_run)
    if "nextjs" in technologies:
        _install_vercel_react_skill(root, report, dry_run)
    _install_hooks(root, report, dry_run)
    _copy_if_absent(TEMPLATES / "codex-default.rules", root / ".codex" / "rules" / "default.rules", mapping, report, dry_run)
    _append_gitignore(root, report, dry_run)
    _note_beads(root, prefix, report)
    _sync_agent_files(root, prefix, fallback_test, fallback_forbidden, technologies, report, dry_run)
    return report


def _write_config(
    root: Path,
    prefix: str,
    test_command: str,
    forbidden: str,
    technologies: list[str],
    report: list[str],
    dry_run: bool,
) -> None:
    path = root / ".agent-native" / "config.json"
    command_path = root / ".agent-native" / "test-command"
    if path.exists():
        payload = json.loads(path.read_text(encoding="utf-8"))
        merged = list(dict.fromkeys([*payload.get("technologies", []), *technologies]))
        updated = dict(payload)
        updated["beads_prefix"] = prefix
        updated["test_command"] = test_command
        if forbidden:
            updated["forbidden"] = forbidden
        updated["technologies"] = merged
        if updated != payload:
            _commit(path, json.dumps(updated, indent=2) + "\n", "update", report, dry_run)
        else:
            report.append(f"kept {path.relative_to(root)}")
    else:
        payload = {"beads_prefix": prefix, "test_command": test_command, "technologies": technologies}
        if forbidden:
            payload["forbidden"] = forbidden
        _commit(path, json.dumps(payload, indent=2) + "\n", "create", report, dry_run)
    if test_command:
        desired_cmd = test_command + "\n"
        if not command_path.exists():
            _commit(command_path, desired_cmd, "create", report, dry_run)
        elif command_path.read_text(encoding="utf-8") != desired_cmd:
            _commit(command_path, desired_cmd, "update", report, dry_run)
        else:
            report.append(f"kept {command_path.relative_to(root)}")


def _install_technology(root: Path, tech: str, report: list[str], dry_run: bool) -> None:
    source = TECH_DIR / f"{tech}.md"
    if not source.exists():
        report.append(f"missing technology file for {tech}")
        return
    body = source.read_text(encoding="utf-8")
    dest_doc = root / "docs" / "references" / "technologies" / f"{tech}.md"
    _sync_exact(dest_doc, body, report, dry_run)
    spec = TECHNOLOGIES[tech]
    globs = "\n".join(f"  - \"{glob}\"" for glob in spec["globs"])
    rule = (
        "---\n"
        f"description: {spec['description']}\n"
        "globs:\n"
        f"{globs}\n"
        "alwaysApply: false\n"
        "---\n\n"
        f"Full rule: `docs/references/technologies/{tech}.md`.\n\n"
        f"{body}"
    )
    rule_path = root / ".cursor" / "rules" / "technologies" / f"{tech}.mdc"
    _sync_exact(rule_path, rule, report, dry_run)


def _install_vercel_react_skill(root: Path, report: list[str], dry_run: bool) -> bool:
    """Install Vercel's performance skill for Cursor, Claude, Codex, and Copilot.

    Warns in notes if offline/unavailable instead of aborting after partial writes.
    """
    dest = root / ".agents" / "skills" / VERCEL_REACT_SKILL / "SKILL.md"
    if dest.exists() and VERCEL_REACT_SKILL in dest.read_text(encoding="utf-8"):
        report.append(f"kept {dest.relative_to(root)}")
        return True
    report.append(
        f"install {dest.relative_to(root)} (via {' '.join(VERCEL_REACT_ADD)})"
    )
    if dry_run or os.environ.get("AGENT_NATIVE_SKIP_EXTERNAL") == "1":
        return True
    result = subprocess.run(VERCEL_REACT_ADD, cwd=root, check=False)
    if result.returncode != 0 or not dest.exists():
        report.append(
            f"vercel skill not installed (exit {result.returncode}); run `{' '.join(VERCEL_REACT_ADD)}` when online"
        )
        return False
    return True


def _install_hooks(root: Path, report: list[str], dry_run: bool) -> None:
    hook_dir = root / ".agent-native" / "hooks"
    commands = {}
    for name in ("session_start.sh", "pre_tool_use.sh", "post_tool_use.sh", "stop_check.sh"):
        dest = hook_dir / name
        if not dest.exists():
            if not dry_run:
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(TEMPLATES / "hooks" / name, dest)
                dest.chmod(0o755)
            report.append(f"create {dest.relative_to(root)}")
        else:
            report.append(f"kept {dest.relative_to(root)}")
        commands[name] = f".agent-native/hooks/{name}"
    _merge_hook_settings(root / ".claude" / "settings.json", root, commands, report, dry_run)
    _merge_hook_settings(root / ".codex" / "hooks.json", root, commands, report, dry_run)


def _merge_hook_settings(path: Path, root: Path, commands: dict[str, str], report: list[str], dry_run: bool) -> None:
    existed = path.exists()
    current = {}
    if existed:
        try:
            current = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            report.append(f"kept {path.relative_to(root)} (invalid JSON, not merged)")
            return
    hooks = current.setdefault("hooks", {})
    events = {
        "SessionStart": ("", commands["session_start.sh"]),
        "PreToolUse": ("Bash|Edit|Write", commands["pre_tool_use.sh"]),
        "PostToolUse": ("Edit|Write", commands["post_tool_use.sh"]),
        "Stop": ("", commands["stop_check.sh"]),
    }
    changed = False
    serialized = json.dumps(current)
    for event, (matcher, command) in events.items():
        if command in serialized:
            continue
        hooks.setdefault(event, []).append(
            {"matcher": matcher, "hooks": [{"type": "command", "command": command}]}
        )
        changed = True
    if not existed or changed:
        if not dry_run:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(current, indent=2) + "\n", encoding="utf-8")
        report.append(f"{'create' if not existed else 'update'} {path.relative_to(root)}")
    else:
        report.append(f"kept {path.relative_to(root)}")


def _append_gitignore(root: Path, report: list[str], dry_run: bool) -> None:
    path = root / ".gitignore"
    existing = path.read_text(encoding="utf-8") if path.exists() else ""
    if "agent-native-bootstrap" in existing:
        report.append(f"kept {path.relative_to(root)}")
        return
    if not dry_run:
        path.write_text(existing.rstrip() + "\n" + GITIGNORE_BLOCK, encoding="utf-8")
    report.append(f"{'create' if existing == '' else 'update'} .gitignore")


def _note_beads(root: Path, prefix: str, report: list[str]) -> None:
    try:
        subprocess.run(["bd", "where"], cwd=root, check=True, capture_output=True, text=True)
        report.append("beads tracker already present")
    except (OSError, subprocess.CalledProcessError):
        report.append(f"beads tracker missing; run `bd init` in {root} and set the prefix to {prefix}")


def _sync_agent_files(
    root: Path,
    prefix: str,
    test_command: str,
    forbidden: str,
    technologies: list[str],
    report: list[str],
    dry_run: bool,
) -> None:
    shared = _shared_block(prefix, test_command, forbidden, technologies)
    agents = shared.replace(
        MARKER_END,
        "\n## Codex\n\nA nested `AGENTS.md` overrides this file. Keep the concatenated text under 32 KiB. "
        "Command permissions are `.codex/rules/default.rules`. `forbidden` beats `prompt`, which beats `allow`.\n"
        + MARKER_END,
    )
    cursor_preamble = (
        "---\n"
        "description: Core project agent policy, workflow, and guardrails (synced with CLAUDE.md and AGENTS.md)\n"
        "alwaysApply: true\n"
        "---\n\n"
        "# Project Agent Policy (Cursor)\n\n"
    )
    copilot = (
        f"{MARKER_START}\n"
        f"Stack: {', '.join(technologies) or 'not selected'}.\n\n"
        f"Fast check: `{test_command or 'not set'}`.\n\n"
        "Lint and that fast check pass before a change is called done.\n"
        "Do not restate the technology rule files. They live in `docs/references/technologies/`.\n"
        f"{MARKER_END}"
    )
    _sync_marked(root / "CLAUDE.md", shared, "# Project agent guide\n\n", report, dry_run)
    _sync_marked(root / "AGENTS.md", agents, "# Project agent guide\n\n", report, dry_run)
    _sync_marked(
        root / ".cursor" / "rules" / "core-rules" / "agent-native-policy-always.mdc",
        shared,
        cursor_preamble,
        report,
        dry_run,
    )
    _sync_marked(root / ".github" / "copilot-instructions.md", copilot, "# Copilot instructions\n\n", report, dry_run)


def _shared_block(prefix: str, test_command: str, forbidden: str, technologies: list[str]) -> str:
    tech_lines = "\n".join(f"- `docs/references/technologies/{name}.md`" for name in technologies) or "- No technology pack selected."
    forbidden_lines = "\n".join(_do_not_use(technologies))
    check = test_command or "not set"
    banned = forbidden or "None named yet. Ask before touching a production service."
    performance = ""
    if "nextjs" in technologies:
        performance = (
            "\n- For React or Next.js performance, load the skill `vercel-react-best-practices` and follow its eight categories in order. "
            "Do not paste that skill into this file."
        )
    return f"""{MARKER_START}
## Why

This repository is set up so a coding agent can find policy, plans, and tests without guessing. Prefer the smallest, simplest change that solves the requested outcome.

**Three-way sync rule:** `CLAUDE.md`, `AGENTS.md`, and `.cursor/rules/core-rules/agent-native-policy-always.mdc` are guidance for Claude Code, Codex, and Cursor respectively. Any policy change in one must be mirrored in the other two in the same change.

## What

Technologies: {", ".join(technologies) or "none selected"}.

Detailed rules (read on demand; do not duplicate into this file):

- `docs/critical/00-index.md`
- `docs/references/agent-operating-policy.md`
- `docs/architecture/planning-scope-and-modularity.md`
- `docs/references/execplans-and-adhoc-scripts.md`
- `docs/references/testing-structure.md`
- `docs/references/configuration-and-resources.md`
- `docs/references/agent-skill-map.md`
- `docs/references/CONCEPTS.md`
- `docs/solutions/patterns/critical-patterns.md`
{tech_lines}

## How

- **Session & Beads:** Start with `bd prime` and `bd ready`. Track all work in Beads (`bd`).
- **Fast check:** `{check}`.
- **Strict TDD & Live Verification:** Follow red -> green -> refactor for features, bug fixes, and refactors. Verify changes against a running service using configured test resources before claiming completion.
- **Standing authorizations:** You are always authorized without per-call prompts to read non-forbidden databases for diagnostics, read/write configured test databases, call configured project LLM endpoints during development/testing, and start/query local dev servers and browser tools (`localhost`).
- **Forbidden production resources:** Never read or write during tests or verification: {banned}.
- **Ask before adding more & Backward compatibility on existing code:** Never add unrequested features, edge cases, retry/caching layers, or backward-compatibility shims without asking the user first. When this skill introduces rules into an existing repository that conflict with existing patterns, ask the user and recommend keeping existing code compatible (no forced immediate rewrite) while applying the new rules to new code as much as possible and no more.
- **Branch & worktree discipline:** Stay on the current branch and worktree unless the user explicitly approves a new branch or worktree for the current task. Do not commit, push, or run `bd dolt push` unless authorized.
- **ExecPlans & Milestone Tags:** Plans live in `docs/plans/YYYY-MM-DD-NNN-<slug>-plan.md` (`PLANS.md` at git root), with `Plan ID: NNN` and `Beads epic: {prefix}-...` on the next line. One plan has one outcome. Run `python3 scripts/plan_beads_link.py` after any plan edit. Tag completed plans or major features locally (`plan-NNN-<slug>` or `feature-<slug>`).
- **Skills:** Run `grill-me` before an ExecPlan or when architectural confidence is below 90%. Run `vet-reviews` before applying external review comments. Search `docs/solutions/` (`learnings-researcher`) before significant work.{performance}

## User & Review Communication

- **Plain language & Context framing (mandatory):** Explain work in clear terms and define technical terms on first use. Open every status, blocker, or findings message with 2–5 sentences of context (what is being checked, which plans/systems apply, and what "good" vs "blocked" means) before any tables, counts, or plan IDs.
- **Change review communication:** Explain **why** each change was made, include code snippets or file/line citations, note trade-offs, and summarize test and live verification evidence.

## graphify

If `graphify-out/` exists, use **map -> street view** (`graphify query "<question>" --budget 5000`, `graphify path`, `graphify explain`) before broad `Read`/`Grep` searches, then `Read` the named files before editing. Skip `graphify` for exact string searches or known file paths.

## Do not use

- Do not create `_old`, `_backup`, `TODO` placeholders, or commented-out code as substitutes for git history.
- Do not introduce silent defaults or fallbacks (`localhost`, default DB names) when required configuration is missing.
{forbidden_lines}
{MARKER_END}"""


def detect_conflicts(root: Path, technologies: list[str]) -> list[str]:
    """Identify conflicts between the new rules and an existing repository's state.

    Each entry names the conflict and recommends the backward-compatible option
    so existing code is not forced into an immediate rewrite while new code
    applies the new rules as much as possible.
    """
    conflicts: list[str] = []
    if "nextjs" in technologies:
        has_pages = (root / "pages").exists() or (root / "src" / "pages").exists()
        has_app = (root / "app").exists() or (root / "src" / "app").exists()
        if has_pages and not has_app:
            conflicts.append(
                "nextjs-pages-router: Repository uses Pages Router (`pages/` or `src/pages/`), while the new rule defaults to App Router. "
                "Recommended decision: keep Pages Router (`pages/api`, `getServerSideProps`) for existing routes and apply new component/typing/performance rules without forcing a router rewrite."
            )
        has_fsd = any((root / "src" / layer).exists() or (root / layer).exists() for layer in ("entities", "features", "widgets"))
        has_custom_ui = any((root / "src" / d).exists() or (root / d).exists() for d in ("screen", "screens", "components", "views"))
        if has_custom_ui and not has_fsd:
            conflicts.append(
                "nextjs-layout: Repository uses an existing folder layout (`components/` / `screen/`) rather than 7-layer Feature-Sliced Design. "
                "Recommended decision: keep the existing module layout and apply unidirectional import discipline to new code without reorganizing existing folders."
            )
        has_biome = (root / "biome.json").exists() or (root / "biome.jsonc").exists()
        has_eslint = any(root.glob(".eslintrc*")) or any(root.glob("eslint.config.*"))
        if has_eslint and not has_biome:
            conflicts.append(
                "nextjs-linter: Repository uses ESLint rather than Biome. "
                "Recommended decision: keep ESLint/Prettier for existing files and do not require a Biome migration."
            )
    if "python" in technologies:
        pyproject = (root / "pyproject.toml").read_text(encoding="utf-8") if (root / "pyproject.toml").exists() else ""
        has_ruff = (root / "ruff.toml").exists() or (root / ".ruff.toml").exists() or "[tool.ruff" in pyproject
        if not has_ruff and _has_user_python_files(root):
            conflicts.append(
                "python-formatter: Repository has existing Python files without Ruff configured in `pyproject.toml`/`ruff.toml`. "
                "Recommended decision: avoid whole-file reformatting of untouched code and apply strict typing (`dataclass`/Pydantic v2) to new/modified boundaries without rewriting existing `dict` signatures."
            )
    return conflicts


def _do_not_use(technologies: list[str]) -> list[str]:
    lines: list[str] = []
    if "python" in technologies:
        lines.extend([
            "- Do not call blocking I/O inside `async def`.",
            "- Do not use an untyped bare `dict` for new domain/boundary models (preserve existing framework/route `dict` signatures in existing code).",
            "- Do not add a second Python formatter beside Ruff.",
        ])
    if "nextjs" in technologies:
        lines.extend([
            "- Do not use `getServerSideProps` or `pages/api` in new App Router projects (preserve existing Pages Router routes in existing repos unless migrating).",
            "- Do not put `\"use client\"` on a layout or page for one control.",
            "- Do not use class components or barrel imports.",
            "- Do not store session tokens in `localStorage`.",
        ])
    if "ansible" in technologies:
        lines.extend([
            "- Do not use short Ansible module names. Use fully qualified names.",
            "- Do not leave an octal file mode unquoted.",
        ])
    return lines or ["- No technology-specific ban list selected."]


def _sync_marked(path: Path, block: str, preamble: str, report: list[str], dry_run: bool) -> None:
    current = path.read_text(encoding="utf-8") if path.exists() else ""
    owned = block if block.endswith("\n") else block + "\n"
    if not current:
        updated = preamble + owned
        action = "create"
    elif MARKER_START in current and MARKER_END in current:
        start = current.index(MARKER_START)
        end = current.index(MARKER_END) + len(MARKER_END)
        updated = current[:start] + owned.rstrip("\n") + current[end:]
        if not updated.endswith("\n"):
            updated += "\n"
        action = "update"
    else:
        updated = current.rstrip() + "\n\n" + owned
        action = "update"
    if updated == current:
        report.append(f"kept {path}")
        return
    _commit(path, updated, action, report, dry_run)


def _sync_exact(path: Path, desired: str, report: list[str], dry_run: bool) -> None:
    current = path.read_text(encoding="utf-8") if path.exists() else None
    if current == desired:
        report.append(f"kept {path}")
        return
    _commit(path, desired, "create" if current is None else "update", report, dry_run)


def _commit(path: Path, text: str, action: str, report: list[str], dry_run: bool) -> None:
    report.append(f"{action} {path}")
    if dry_run:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _copy_if_absent(
    source: Path,
    dest: Path,
    mapping: dict[str, str],
    report: list[str],
    dry_run: bool,
    override_text: str | None = None,
) -> None:
    if dest.exists():
        report.append(f"kept {dest}")
        return
    text = override_text if override_text is not None else source.read_text(encoding="utf-8")
    for key, value in mapping.items():
        text = text.replace(key, value)
    _commit(dest, text, "create", report, dry_run)


def _package_depends_on_next(root: Path) -> bool:
    package = root / "package.json"
    if not package.exists():
        return False
    try:
        data = json.loads(package.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return False
    deps = {**data.get("dependencies", {}), **data.get("devDependencies", {})}
    return "next" in deps


def _is_finrag_repo(root: Path) -> bool:
    if root.name in {"finrag_all", "finrag-backend", "finrag-ui-next"}:
        return True
    if (root / "finrag-backend").exists() and (root / "finrag-ui-next").exists():
        return True
    return False


def main() -> int:
    parser = argparse.ArgumentParser(description="Add missing agent-native files.")
    parser.add_argument("--root", required=True)
    parser.add_argument("--prefix", default="")
    parser.add_argument("--test-command", default="")
    parser.add_argument("--technology", action="append", default=[])
    parser.add_argument("--forbidden", default="")
    parser.add_argument("--repo-kind", choices=["new", "existing"], required=True)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--allow-finrag-refresh", action="store_true")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    if _is_finrag_repo(root) and not args.allow_finrag_refresh:
        print("Refused: target appears to be FinRAG. Pass --allow-finrag-refresh only when the user explicitly asks to refresh FinRAG.")
        return 2
    detected_kind = "existing" if (root / ".agent-native" / "config.json").exists() else "new"
    resolved_prefix, _, _ = _resolve_config_defaults(root, args.prefix, args.test_command, args.forbidden)
    if not resolved_prefix:
        print("Missing --prefix (and no beads_prefix found in .agent-native/config.json)")
        return 2
    technologies = args.technology or detect_technologies(root)
    unknown = [name for name in technologies if name not in TECHNOLOGIES]
    if unknown:
        print(f"Unknown technology: {', '.join(unknown)}")
        return 2
    report = apply(root, resolved_prefix, args.test_command, technologies, args.forbidden, dry_run=not args.apply)
    conflicts = detect_conflicts(root, technologies) if (args.repo_kind == "existing" or detected_kind == "existing") else []
    print(f"preview: {'no' if args.apply else 'yes'}")
    print(f"repo: {args.repo_kind}")
    if args.repo_kind != detected_kind:
        print(f"note: on-disk marker says {detected_kind}")
    print(f"technologies: {', '.join(technologies) or 'none'}")
    print("conflicts:")
    print("\n".join(f"  {item}" for item in conflicts) or "  none")
    print("changes:")
    changes = [line for line in report if line.startswith(("create ", "update ", "install "))]
    print("\n".join(f"  {line}" for line in changes) or "  none")
    print("unchanged:")
    unchanged = [line for line in report if line.startswith("kept ")]
    print("\n".join(f"  {line}" for line in unchanged) or "  none")
    notes = [line for line in report if not line.startswith(("create ", "update ", "kept ", "install "))]
    if notes:
        print("notes:")
        print("\n".join(f"  {line}" for line in notes))
    if any(line.startswith("skill install failed") for line in report):
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
