import json
import os
import subprocess
import sys
from pathlib import Path

APPLY = Path(__file__).resolve().parent / "apply.py"
ACCEPT = Path(__file__).resolve().parent / "accept.py"


def run(script: Path, *args: str) -> subprocess.CompletedProcess[str]:
    env = os.environ.copy()
    env["AGENT_NATIVE_SKIP_EXTERNAL"] = "1"
    return subprocess.run([sys.executable, str(script), *args], check=False, capture_output=True, text=True, env=env)


def test_dry_run_lists_changes_and_writes_nothing(tmp_path: Path) -> None:
    (tmp_path / "app.py").write_text("print('hi')\n", encoding="utf-8")
    result = run(
        APPLY,
        "--root",
        str(tmp_path),
        "--prefix",
        "app",
        "--repo-kind",
        "new",
        "--test-command",
        "pytest -q",
        "--forbidden",
        "production database",
    )
    assert result.returncode == 0, result.stderr
    assert "preview: yes" in result.stdout
    assert "repo: new" in result.stdout
    assert "create " in result.stdout
    assert "CLAUDE.md" in result.stdout
    assert "vercel-react-best-practices" not in result.stdout
    assert not (tmp_path / "PLANS.md").exists()
    assert not (tmp_path / "CLAUDE.md").exists()
    assert not (tmp_path / ".cursor").exists()


def test_apply_creates_agent_files_and_python_rules(tmp_path: Path) -> None:
    (tmp_path / "app.py").write_text("print('hi')\n", encoding="utf-8")
    result = run(
        APPLY,
        "--root",
        str(tmp_path),
        "--prefix",
        "app",
        "--repo-kind",
        "new",
        "--apply",
        "--test-command",
        "pytest -q",
        "--forbidden",
        "production database",
    )
    assert result.returncode == 0, result.stderr
    claude = (tmp_path / "CLAUDE.md").read_text(encoding="utf-8")
    agents = (tmp_path / "AGENTS.md").read_text(encoding="utf-8")
    assert "bd prime" in claude
    assert "Plan ID: NNN" in claude
    assert "32 KiB" in agents
    assert "production database" in (tmp_path / "docs" / "solutions" / "patterns" / "critical-patterns.md").read_text()
    rule = (tmp_path / ".cursor" / "rules" / "technologies" / "python.mdc").read_text(encoding="utf-8")
    assert "blocking I/O" in rule
    assert "One change has one outcome" in rule
    accept = run(ACCEPT, "--root", str(tmp_path))
    assert accept.returncode == 0, accept.stdout + accept.stderr


def test_existing_repo_keeps_preamble_and_second_apply_is_stable(tmp_path: Path) -> None:
    (tmp_path / "CLAUDE.md").write_text("# Stay\n", encoding="utf-8")
    (tmp_path / "PLANS.md").write_text("# Custom plans\n", encoding="utf-8")
    (tmp_path / "src" / "pages" / "api").mkdir(parents=True)
    (tmp_path / "package.json").write_text(json.dumps({"dependencies": {"next": "15.0.0"}}), encoding="utf-8")
    preview = run(APPLY, "--root", str(tmp_path), "--prefix", "web", "--repo-kind", "existing", "--technology", "nextjs")
    assert preview.returncode == 0, preview.stderr
    assert (tmp_path / "CLAUDE.md").read_text(encoding="utf-8") == "# Stay\n"
    assert "update " in preview.stdout
    assert "nextjs-pages-router:" in preview.stdout
    assert "Recommended decision:" in preview.stdout
    applied = run(
        APPLY,
        "--root",
        str(tmp_path),
        "--prefix",
        "web",
        "--repo-kind",
        "existing",
        "--technology",
        "nextjs",
        "--apply",
    )
    assert applied.returncode == 0, applied.stderr
    text = (tmp_path / "CLAUDE.md").read_text(encoding="utf-8")
    assert text.startswith("# Stay\n")
    assert "agent-native-bootstrap:start" in text
    assert "getServerSideProps" in text
    assert (tmp_path / "PLANS.md").read_text(encoding="utf-8") == "# Custom plans\n"
    rule = (tmp_path / ".cursor" / "rules" / "technologies" / "nextjs.mdc").read_text(encoding="utf-8")
    assert "One change has one outcome" in rule
    assert "vercel-react-best-practices" in rule
    assert "install .agents/skills/vercel-react-best-practices/SKILL.md" in preview.stdout
    assert "vercel-react-best-practices" in text
    skill = tmp_path / ".agents" / "skills" / "vercel-react-best-practices" / "SKILL.md"
    skill.parent.mkdir(parents=True, exist_ok=True)
    skill.write_text("name: vercel-react-best-practices\n", encoding="utf-8")
    second = run(
        APPLY,
        "--root",
        str(tmp_path),
        "--prefix",
        "web",
        "--repo-kind",
        "existing",
        "--technology",
        "nextjs",
        "--apply",
    )
    assert second.returncode == 0, second.stderr
    assert "install npx" not in second.stdout
    assert "vercel-react-best-practices/SKILL.md" in second.stdout
    assert "\n  create " not in second.stdout
    assert (tmp_path / "CLAUDE.md").read_text(encoding="utf-8") == text
