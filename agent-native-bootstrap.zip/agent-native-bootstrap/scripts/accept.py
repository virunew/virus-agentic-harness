#!/usr/bin/env python3
"""Check the agent-native substrate and agent entry files."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

REQUIRED = [
    "PLANS.md",
    "docs/critical/00-index.md",
    "docs/architecture/planning-scope-and-modularity.md",
    "docs/references/agent-operating-policy.md",
    "docs/references/execplans-and-adhoc-scripts.md",
    "docs/references/testing-structure.md",
    "docs/references/configuration-and-resources.md",
    "docs/references/agent-skill-map.md",
    "docs/references/CONCEPTS.md",
    "docs/solutions/patterns/critical-patterns.md",
    "docs/plans/completed/README.md",
    "docs/plans/archive/README.md",
    "docs/plans/improvements/README.md",
    "docs/plans/good_to_have/README.md",
    "docs/brainstorms/README.md",
    ".agents/skills/beads/SKILL.md",
    ".cursor/rules/beads.mdc",
    ".cursor/rules/graphify.mdc",
    ".cursor/rules/core-rules/agent-native-policy-always.mdc",
    "scripts/plan_beads_link.py",
    "tests/test_plan_beads_link.py",
    ".agent-native/config.json",
    ".codex/rules/default.rules",
    ".codex/hooks.json",
    ".claude/settings.json",
    "CLAUDE.md",
    "AGENTS.md",
    ".github/copilot-instructions.md",
    ".agent-native/hooks/session_start.sh",
    ".agent-native/hooks/pre_tool_use.sh",
    ".agent-native/hooks/post_tool_use.sh",
    ".agent-native/hooks/stop_check.sh",
]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True)
    args = parser.parse_args()
    root = Path(args.root).resolve()
    missing = [path for path in REQUIRED if not (root / path).exists()]
    config_path = root / ".agent-native" / "config.json"
    if config_path.exists():
        config = json.loads(config_path.read_text(encoding="utf-8"))
        for tech in config.get("technologies", []):
            rule = root / ".cursor" / "rules" / "technologies" / f"{tech}.mdc"
            doc = root / "docs" / "references" / "technologies" / f"{tech}.md"
            if not rule.exists():
                missing.append(str(rule.relative_to(root)))
            if not doc.exists():
                missing.append(str(doc.relative_to(root)))
            if tech == "nextjs":
                skill = root / ".agents" / "skills" / "vercel-react-best-practices" / "SKILL.md"
                if not skill.exists():
                    missing.append(str(skill.relative_to(root)))
    if missing:
        print("missing:")
        for path in missing:
            print(f"  {path}")
        return 1
    print("substrate ok")
    return 0


if __name__ == "__main__":
    sys.exit(main())
