---
name: beads
description: Use when this repository tracks work with bd, or when an ExecPlan with a Plan ID is created or its work units change.
---

# Beads

Run `bd prime` at the start of a session. If it prints nothing, run `bd where`. If there is no tracker, stop. Do not create one and do not point `BEADS_DIR` at another repository.

## Everyday commands

```bash
bd ready
bd show <id>
bd update <id> --claim
bd create "Short title" --description="Why it exists and what to do" --type=task --priority=2
bd close <id> --reason="Completed"
bd export -o .beads/issues.jsonl
```

Do not use `bd edit`. Do not use a markdown TODO file as the task list. Do not commit or push unless the user asks.

## ExecPlan sync

Use this when a plan file has a `Plan ID:` line. Skip a requirements document.

The label is `plan-` plus the id, such as `plan-001`. Search before creating:

```bash
bd list --label plan-001 --json
bd list --label plan-001 --status=closed --json
```

One epic per plan id. If one exists, update it. Do not create a second epic.

An unfinished plan names its epic, and the epic names the plan. Unfinished means the file is under `docs/plans/`, not in `completed/`, `archive/`, `improvements/`, or `good_to_have/`, and a Progress box is open. A plan with no boxes stays unfinished until `Status:` says complete, closed, or parked.

- The line after `Plan ID:` is `Beads epic: <id>`. If that epic is missing on an unfinished plan, create it even when this run did not create the plan file:
  `bd create "Plan NNN: <first heading>" --type=epic --labels=plan-NNN --spec-id <plan-path> --description="Tracks ExecPlan <plan-path>"`
- The epic label is `plan-NNN`. `spec_id` is the plan path relative to the repository root (`bd update <id> --spec-id <plan-path>` when updating an existing epic).
- Epic title: `Plan NNN: <first heading>`.
- Tasks are `### Milestone` headings, or Progress items that name work. Concrete steps of a task are subtasks. Decision log entries, surprises, outcomes, dated journal notes inside `Progress`, shell transcripts, expected outputs, and validation commands are not issues.
- When a plan is deepened and keeps existing Progress items and timestamps, update those issues in place; do not close or recreate them.
- `bd dep add <later> <earlier>` means later is blocked by earlier. Chain tasks in plan order. When a plan waits on another unfinished plan, chain its epic to the earlier plan's epic. Never block a parent with its own child.
- A checked Progress box closes that issue and its open children, children first, reason `Plan NNN records this step complete`. If `bd close` is refused because a dependency is still open in Beads, run `bd close <id> --force --reason="Plan NNN records this step complete"`.
- A removed step is closed with reason `Plan NNN dropped this step`. Do not delete it.
- When every work-unit box is checked and the plan says it is complete, close the epic.
- Run this section again by matching existing issues. Do not duplicate them.
- Do not run `bd dolt push` or `bd repo sync` unless the user asks.

From the repository root, `python3 scripts/plan_beads_link.py` must exit 0 before the plan edit is finished.

After create, update, or close:

```bash
bd export -o .beads/issues.jsonl
```
