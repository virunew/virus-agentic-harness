import importlib.util
from pathlib import Path


def load_checker():
    path = Path(__file__).resolve().parents[1] / "scripts" / "plan_beads_link.py"
    spec = importlib.util.spec_from_file_location("plan_beads_link", path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


link = load_checker()


def test_duplicate_plan_id_fails() -> None:
    plans = [
        ("docs/plans/2026-01-01-001-one-plan.md", "Plan ID: 001\n"),
        ("docs/plans/2026-01-02-001-two-plan.md", "Plan ID: 001\n"),
    ]
    errors = link.check_unique_plan_ids(plans)
    assert len(errors) == 1
    assert "001" in errors[0]


def test_cross_package_duplicate_plan_id_fails() -> None:
    by_pkg = {
        "backend": [("docs/plans/004-api-plan.md", "Plan ID: 004\n")],
        "frontend": [("docs/plans/004-ui-plan.md", "Plan ID: 004\n")],
    }
    errors = link.check_unique_plan_ids([], plans_by_package=by_pkg)
    assert len(errors) == 1
    assert "backend/docs/plans/004-api-plan.md" in errors[0]
    assert "frontend/docs/plans/004-ui-plan.md" in errors[0]


def test_missing_epic_line_fails() -> None:
    text = "Plan ID: 001\n\n- [ ] Still open\n"
    errors = link.check_plan("docs/plans/001-plan.md", text, [], "app")
    assert any("Beads epic" in error for error in errors)


def test_matching_epic_passes() -> None:
    text = "Plan ID: 002\nBeads epic: app-ab1\n\n- [ ] Build\n"
    issues = [{"id": "app-ab1", "issue_type": "epic", "labels": ["plan-002"], "spec_id": "docs/plans/002-plan.md"}]
    assert link.check_plan("docs/plans/002-plan.md", text, issues, "app") == []


def test_epic_id_mismatch_fails() -> None:
    text = "Plan ID: 002\nBeads epic: app-ab1\n\n- [ ] Build\n"
    issues = [{"id": "app-other", "issue_type": "epic", "labels": ["plan-002"], "spec_id": "docs/plans/002-plan.md"}]
    errors = link.check_plan("docs/plans/002-plan.md", text, issues, "app")
    assert any("app-other" in error for error in errors)


def test_spec_id_mismatch_fails() -> None:
    text = "Plan ID: 002\nBeads epic: app-ab1\n\n- [ ] Build\n"
    issues = [{"id": "app-ab1", "issue_type": "epic", "labels": ["plan-002"], "spec_id": "docs/plans/wrong.md"}]
    errors = link.check_plan("docs/plans/002-plan.md", text, issues, "app")
    assert any("spec_id" in error for error in errors)


def test_closed_status_without_checkboxes_is_finished() -> None:
    text = "Plan ID: 005\nStatus: Complete\n"
    assert link.plan_is_unfinished("docs/plans/005-plan.md", text) is False


def test_parked_folder_is_out_of_scope() -> None:
    text = "Plan ID: 003\n\n- [ ] Later\n"
    assert link.plan_is_unfinished("docs/plans/improvements/003-plan.md", text) is False
