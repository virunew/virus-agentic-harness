"""Check that unfinished ExecPlans and their Beads epics name each other.

Every `Plan ID:` line must be unique across the repository (and any sibling
packages listed in `.agent-native/config.json` under `sibling_packages`, unless
`--single-package` is passed). The epic link uses `beads_prefix` in
`.agent-native/config.json`.
"""

from __future__ import annotations

import argparse
import json
import logging
import re
import subprocess
import sys
from pathlib import Path

LOGGER = logging.getLogger(__name__)
SKIP_DIRS = frozenset({"completed", "archive", "improvements", "good_to_have"})
PLAN_ID_RE = re.compile(r"^Plan ID:\s*(\d{3})\b", re.MULTILINE)
OPEN_BOX_RE = re.compile(r"^- \[ \]", re.MULTILINE)
ANY_BOX_RE = re.compile(r"^- \[[ xX]\]", re.MULTILINE)
STATUS_RE = re.compile(r"^Status:\s*(.+)$", re.MULTILINE)
CLOSED_STATUS_RE = re.compile(r"\b(complete|completed|closed|parked)\b", re.IGNORECASE)


def epic_line_re(prefix: str) -> re.Pattern[str]:
    return re.compile(rf"^Beads epic:\s*({re.escape(prefix)}-[a-z0-9]+)\s*$", re.MULTILINE)


def plan_is_unfinished(relative_path: str, text: str) -> bool:
    if any(part in SKIP_DIRS for part in Path(relative_path).parts):
        return False
    if _plan_id(text) is None:
        return False
    if ANY_BOX_RE.search(text):
        return OPEN_BOX_RE.search(text) is not None
    status = STATUS_RE.search(text)
    if status and CLOSED_STATUS_RE.search(status.group(1)):
        return False
    return True


def check_plan(relative_path: str, text: str, issues: list[dict], prefix: str) -> list[str]:
    if not plan_is_unfinished(relative_path, text):
        return []
    plan_id = _plan_id(text)
    label = f"plan-{plan_id:03d}"
    errors: list[str] = []
    epic_ids = epic_line_re(prefix).findall(text)
    named = epic_ids[0] if len(epic_ids) == 1 else None
    if named is None:
        errors.append(f"Plan {plan_id:03d} ({relative_path}): expected one 'Beads epic: {prefix}-...' line")
    labeled = [
        issue
        for issue in issues
        if issue.get("issue_type") == "epic" and label in (issue.get("labels") or [])
    ]
    if len(labeled) != 1:
        errors.append(f"Plan {plan_id:03d} ({relative_path}): expected one epic with label {label}")
        return errors
    epic = labeled[0]
    if named is not None and named != epic.get("id"):
        errors.append(f"Plan {plan_id:03d}: Beads epic line says {named} but label {label} is on {epic.get('id')}")
    if (epic.get("spec_id") or "") != relative_path:
        errors.append(f"Plan {plan_id:03d}: spec_id is {epic.get('spec_id')!r}, expected {relative_path!r}")
    return errors


def check_unique_plan_ids(plans: list[tuple[str, str]], plans_by_package: dict[str, list[tuple[str, str]]] | None = None) -> list[str]:
    seen: dict[int, list[str]] = {}
    if plans_by_package is not None:
        for package_name, pkg_plans in sorted(plans_by_package.items()):
            for relative_path, text in pkg_plans:
                plan_id = _plan_id(text)
                if plan_id is None:
                    continue
                seen.setdefault(plan_id, []).append(f"{package_name}/{relative_path}")
    else:
        for relative_path, text in plans:
            plan_id = _plan_id(text)
            if plan_id is None:
                continue
            seen.setdefault(plan_id, []).append(relative_path)
    return [f"Plan {plan_id:03d} repeats in {', '.join(paths)}" for plan_id, paths in sorted(seen.items()) if len(paths) > 1]


def load_plans(root: Path) -> list[tuple[str, str]]:
    plans_root = root / "docs" / "plans"
    if not plans_root.exists():
        return []
    loaded: list[tuple[str, str]] = []
    for path in sorted(plans_root.rglob("*plan.md")):
        loaded.append((path.relative_to(root).as_posix(), path.read_text(encoding="utf-8")))
    return loaded


def load_config(root: Path) -> dict:
    config_path = root / ".agent-native" / "config.json"
    if not config_path.exists():
        raise RuntimeError(f"Missing {config_path}")
    return json.loads(config_path.read_text(encoding="utf-8"))


def load_prefix(root: Path) -> str:
    prefix = load_config(root).get("beads_prefix")
    if not prefix:
        raise RuntimeError(f"{root / '.agent-native' / 'config.json'} has no beads_prefix")
    return str(prefix)


def load_issues(root: Path) -> list[dict]:
    completed = subprocess.run(
        ["bd", "list", "--json", "--all", "--flat", "-n", "0"],
        cwd=root,
        check=True,
        capture_output=True,
        text=True,
    )
    payload = json.loads(completed.stdout or "[]")
    if isinstance(payload, dict):
        return payload.get("issues", [])
    return payload


def evaluate(
    plans: list[tuple[str, str]],
    issues: list[dict],
    prefix: str,
    plans_by_package: dict[str, list[tuple[str, str]]] | None = None,
) -> list[str]:
    failures = check_unique_plan_ids(plans, plans_by_package=plans_by_package)
    for relative_path, text in plans:
        failures.extend(check_plan(relative_path, text, issues, prefix))
    return failures


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Verify ExecPlan <-> Beads epic links.")
    parser.add_argument(
        "--single-package",
        action="store_true",
        help="Check Plan ID uniqueness only in this package even if sibling_packages are configured.",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    args = parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    try:
        config = load_config(root)
        prefix = load_prefix(root)
    except (OSError, json.JSONDecodeError, RuntimeError) as exc:
        LOGGER.error("%s", exc)
        return 1
    plans = load_plans(root)
    plans_by_package: dict[str, list[tuple[str, str]]] | None = None
    siblings = config.get("sibling_packages") or []
    if siblings and not args.single_package:
        plans_by_package = {root.name: plans}
        for sibling in siblings:
            sibling_root = root.parent / sibling
            if not sibling_root.exists():
                LOGGER.error("Missing sibling package %s next to %s (pass --single-package to skip)", sibling, root.name)
                return 1
            plans_by_package[sibling] = load_plans(sibling_root)
    unfinished = sum(1 for path, text in plans if plan_is_unfinished(path, text))
    if unfinished == 0:
        failures = check_unique_plan_ids(plans, plans_by_package=plans_by_package)
        if failures:
            for failure in failures:
                LOGGER.error(failure)
            return 1
        LOGGER.info("plan-beads link ok for 0 unfinished plans")
        return 0
    try:
        issues = load_issues(root)
    except (OSError, subprocess.CalledProcessError, json.JSONDecodeError, RuntimeError) as exc:
        LOGGER.error("%s", exc)
        return 1
    failures = evaluate(plans, issues, prefix, plans_by_package=plans_by_package)
    if failures:
        for failure in failures:
            LOGGER.error(failure)
        return 1
    LOGGER.info("plan-beads link ok for %s unfinished plans", unfinished)
    return 0


def _plan_id(text: str) -> int | None:
    match = PLAN_ID_RE.search(text)
    return None if match is None else int(match.group(1))


if __name__ == "__main__":
    sys.exit(main())
