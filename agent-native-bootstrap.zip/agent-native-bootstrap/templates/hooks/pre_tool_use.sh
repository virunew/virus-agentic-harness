#!/bin/sh
# PreToolUse: exit 2 blocks the tool. stderr is returned to the agent.
input=$(cat)
if ! command -v jq >/dev/null 2>&1; then
  if printf '%s' "$input" | grep -Eq '"tool_name"[[:space:]]*:[[:space:]]*"Bash"' &&
    printf '%s' "$input" | grep -Eq '(^|[^A-Za-z0-9_])rm[[:space:]]+-[A-Za-z]*r|mkfs|dd[[:space:]]+if='; then
    echo "Blocked destructive command." >&2
    exit 2
  fi
  echo "jq is not installed; path checks were skipped." >&2
  exit 0
fi
tool_name=$(printf '%s' "$input" | jq -r '.tool_name // empty' 2>/dev/null || true)
command_text=$(printf '%s' "$input" | jq -r '.tool_input.command // empty' 2>/dev/null || true)
file_path=$(printf '%s' "$input" | jq -r '.tool_input.file_path // .tool_input.path // empty' 2>/dev/null || true)

if [ "$tool_name" = "Bash" ] || [ -n "$command_text" ]; then
  if printf '%s' "$command_text" | grep -Eq '(^|[[:space:];|&])rm[[:space:]]+-[A-Za-z]*r|mkfs|dd[[:space:]]+if='; then
    echo "Blocked destructive command." >&2
    exit 2
  fi
  if printf '%s' "$command_text" | grep -Eq '(^|[[:space:];|&])chmod[[:space:]]+(-R|777)'; then
    echo "Blocked broad chmod." >&2
    exit 2
  fi
fi

case "$file_path" in
  *.env.example|*.env.sample|*.env.template)
    ;;
  .env|.env.*|*.env|*.env.*|env|env_*|*/env|*/env_*)
    echo "Blocked write to an env file. Ask the user." >&2
    exit 2
    ;;
  migrations/*|*/migrations/*|alembic/versions/*|*/alembic/versions/*|scripts/deploy*|*/scripts/deploy*)
    echo "Blocked write to migrations or deploy scripts. Ask the user." >&2
    exit 2
    ;;
esac
exit 0
