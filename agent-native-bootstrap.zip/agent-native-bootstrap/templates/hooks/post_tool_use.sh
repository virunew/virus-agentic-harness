#!/bin/sh
# PostToolUse: format, lint, and typecheck the edited file. Missing tools are reported; real check failures exit 2.
input=$(cat)
if ! command -v jq >/dev/null 2>&1; then
  echo "jq is not installed; PostToolUse check skipped." >&2
  exit 0
fi
file_path=$(printf '%s' "$input" | jq -r '.tool_input.file_path // .tool_input.path // empty' 2>/dev/null || true)
[ -n "$file_path" ] && [ -f "$file_path" ] || exit 0
root=$(git rev-parse --show-toplevel 2>/dev/null || pwd)

case "$file_path" in
  *.py)
    ruff_bin=""
    if [ -x "$root/.venv/bin/ruff" ]; then
      ruff_bin="$root/.venv/bin/ruff"
    elif command -v ruff >/dev/null 2>&1; then
      ruff_bin="ruff"
    fi
    if [ -n "$ruff_bin" ]; then
      if ! ("$ruff_bin" format "$file_path" && "$ruff_bin" check --fix "$file_path") >&2; then
        exit 2
      fi
    else
      echo "ruff is not installed; Python format/lint hook skipped." >&2
    fi
    ;;
  *.ts|*.tsx|*.js|*.jsx)
    if command -v biome >/dev/null 2>&1; then
      if ! biome check --write "$file_path" >&2; then
        exit 2
      fi
    elif command -v npx >/dev/null 2>&1; then
      npx --no-install prettier --write "$file_path" >/dev/null 2>&1 || echo "Neither biome nor prettier is installed." >&2
    else
      echo "Neither biome nor npx is installed; JS/TS format hook skipped." >&2
    fi
    case "$file_path" in
      *.ts|*.tsx)
        dir=$(dirname "$file_path")
        tsconfig=""
        while [ "$dir" != "/" ] && [ "$dir" != "." ]; do
          if [ -f "$dir/tsconfig.json" ]; then
            tsconfig="$dir/tsconfig.json"
            break
          fi
          dir=$(dirname "$dir")
        done
        if [ -z "$tsconfig" ] && [ -f "$root/tsconfig.json" ]; then
          tsconfig="$root/tsconfig.json"
        fi
        if [ -n "$tsconfig" ]; then
          if command -v npx >/dev/null 2>&1; then
            if ! (cd "$(dirname "$tsconfig")" && npx --no-install tsc --noEmit --pretty false) >&2; then
              exit 2
            fi
          else
            echo "npx is not installed; tsc check skipped." >&2
          fi
        fi
        ;;
    esac
    ;;
  *.yml|*.yaml)
    case "$file_path" in
      *playbooks*|*roles*|*molecule*)
        if command -v yamllint >/dev/null 2>&1; then
          if ! yamllint "$file_path" >&2; then
            exit 2
          fi
        else
          echo "yamllint is not installed; YAML lint skipped." >&2
        fi
        if command -v ansible-lint >/dev/null 2>&1; then
          if ! ansible-lint "$file_path" >&2; then
            exit 2
          fi
        else
          echo "ansible-lint is not installed; Ansible lint skipped." >&2
        fi
        ;;
    esac
    ;;
esac
exit 0
