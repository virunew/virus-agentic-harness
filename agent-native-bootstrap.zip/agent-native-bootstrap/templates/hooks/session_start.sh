#!/bin/sh
# SessionStart: branch, recent commits, Beads, and a short issue list.
set -eu
if git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  echo "branch: $(git rev-parse --abbrev-ref HEAD 2>/dev/null || true)"
  git log -5 --oneline 2>/dev/null || true
fi
if command -v bd >/dev/null 2>&1; then
  bd prime 2>/dev/null || true
  bd ready 2>/dev/null || true
elif command -v gh >/dev/null 2>&1; then
  gh issue list --limit 5 2>/dev/null || true
fi
exit 0
