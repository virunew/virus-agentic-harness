#!/bin/sh
# Stop: run the fast test command when code changed. Exit 2 keeps the agent working.
input=$(cat)
if command -v jq >/dev/null 2>&1; then
  active=$(printf '%s' "$input" | jq -r '.stop_hook_active // false' 2>/dev/null || echo "false")
  [ "$active" = "true" ] && exit 0
elif printf '%s' "$input" | grep -Eq '"stop_hook_active"[[:space:]]*:[[:space:]]*true'; then
  exit 0
fi

root=$(git rev-parse --show-toplevel 2>/dev/null || pwd)
command_file="$root/.agent-native/test-command"
stamp_file="$root/.agent-native/last-test-ok"
[ -f "$command_file" ] || exit 0
test_command=$(tr -d '\r' < "$command_file")
[ -n "$test_command" ] || exit 0

if git -C "$root" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  dirty=$(git -C "$root" status --porcelain 2>/dev/null || true)
  if [ -z "$dirty" ] && [ -f "$stamp_file" ]; then
    exit 0
  fi
fi

# Run from the repo root under bash so `source` works, and send output to stderr on failure.
if ! (cd "$root" && bash -c "$test_command") >&2; then
  echo "Fast check failed: $test_command" >&2
  exit 2
fi
mkdir -p "$root/.agent-native"
: > "$stamp_file"
exit 0
