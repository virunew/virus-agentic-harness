# Planning Scope And Modularity

## TOC

- [Purpose](#purpose)
- [Plan Scope](#plan-scope)
- [Unique Plan IDs](#unique-plan-ids)
- [Adhoc Scripts](#adhoc-scripts)
- [Modular Coding Style](#modular-coding-style)
- [Deep Modules](#deep-modules)
- [Once And Only Once](#once-and-only-once)
- [Helper Folders](#helper-folders)
- [File Size](#file-size)
- [What Stays In The Main File](#what-stays-in-the-main-file)
- [Contract-First Design](#contract-first-design)
- [How This Relates To Minimal Change](#how-this-relates-to-minimal-change)
- [Policy Sync](#policy-sync)

## Purpose

Architecture decisions for how agents plan work and structure code. These are mandatory coding and work styles, not optional preferences.

## Plan Scope

When devising plans (brainstorms, ExecPlans, multi-step implementation plans):

1. Lean toward **one easily achievable goal** per plan.
2. Prefer a shippable slice that can be verified end-to-end.
3. If a draft plan is ambitious or has **too many moving pieces** (for example: API + parser + database + UI + migration in one plan), **stop and ask the user** to break it into smaller plans before continuing.
4. Do not silently expand a focused plan into a mega-plan.

Signs a plan should be split:

- More than one independently deployable outcome.
- Multiple subsystems that can fail or ship on different schedules.
- A milestone list that cannot be verified until several unrelated pieces land.

## Unique Plan IDs

Every new ExecPlan under `docs/plans/` must use a **unique three-digit plan ID** in its filename:

```text
docs/plans/YYYY-MM-DD-NNN-<slug>-plan.md
```

Before creating a plan, search `docs/plans/` (and any configured sibling package `docs/plans/` trees) and assign the next unused `NNN`. State `Plan ID: NNN` near the top of the document. Do not reuse IDs after a plan file exists. An unfinished plan also records `Beads epic: {{PREFIX}}-...` and the epic's `spec_id`; `python3 scripts/plan_beads_link.py` must pass.

Full rules: `docs/references/execplans-and-adhoc-scripts.md`.

## Adhoc Scripts

One-time scripts — migrations, destructive maintenance, dry-run/apply CLIs, and other operational tooling not part of the long-lived app — belong in `scripts/adhoc/`.

- **Plan-implementing scripts:** `scripts/adhoc/NNN-<descriptive-slug>.*`
- **Other one-time scripts:** `scripts/adhoc/<descriptive-slug>.*`
- Reusable logic stays in the application tree; adhoc files orchestrate only.
- Long-lived entry points (`scripts/plan_beads_link.py`, environment activation scripts) stay in `scripts/`.

The ExecPlan must name exact adhoc script paths in `Plan of Work` and `Concrete Steps`.

## Modular Coding Style

Always structure required work modularly:

1. Prefer **named functions** over large inline blocks when logic can be extracted cleanly.
2. Separate concerns into a **deep module** with a simple interface (orchestration vs utilities, API vs domain logic, parsing vs persistence). See [Deep Modules](#deep-modules).
3. Keep main/entry files focused on **flow and orchestration**.
4. In Python or backend scripts, put that script's helpers in a `{script_stem}_helpers/` folder created beside the script. See [Helper Folders](#helper-folders).
5. Keep main orchestration files focused (aim under ~200 lines when practical). A deep helper may be longer than that.

### Good

```python
# src/pipeline/run_import.py — orchestration only
from src.pipeline.run_import_helpers.prepare import (
    prepare_batch_files,
    record_import_failure,
)

def run_import_step(batch_id: str) -> dict:
    files = prepare_batch_files(batch_id)
    return process_files(files)
```

### Bad

```python
# Large inline parsing, error formatting, and DB writes inside the main flow
def run_import_step(batch_id: str) -> dict:
    # 80+ lines of path munging, exception formatting, DB writes...
    pass
```

## Deep Modules

Prefer **fewer deep modules with simple interfaces** over many shallow modules with more granular and complex interfaces.

A deep module hides substantial behavior behind a small public interface. Callers use a few clear functions. They do not assemble the implementation themselves.

A shallow module has an interface nearly as large as the work it does. Typical signs:

- One function per file for a single concern.
- Pass-through wrappers that only forward to the next function.
- A caller that must invoke many tiny functions in a fixed order to finish one task.

Apply this when structuring code for a requested change:

1. Keep the public interface small: few functions, obvious inputs and outputs.
2. Keep related implementation behind that interface, in one module when the behavior belongs together. Named functions inside the module are fine.
3. Add another module only when it owns a separate concern and has its own simple interface.
4. Do not split a module only to reduce its line count when the split creates shallow modules.
5. Main files stay orchestration. The helper they call should be deep, not a chain of thin wrappers.

### Good

```python
def import_statement(source: StatementSource) -> ImportResult:
    """One call. Parsing, checks, and persistence stay inside this module."""
```

### Bad

```python
# The caller must know the internal steps and their order.
rows = parse_rows(source)
checked = validate_rows(rows)
mapped = map_rows(checked)
write_rows(mapped)
```

## Once And Only Once

Kent Beck's name for this rule: a behavior lives in one place. Every path that needs it calls that place.

When several code paths do the same thing, do not write a separate version of that behavior in each path. Write one function, hook, or script, and make those paths call it.

Apply this to the change you are already making. It does not authorize a sweep that merges unrelated copies, and it does not authorize extra features.

## Helper Folders

All helpers for one main Python script live in one folder created at the same level as that script.

```text
src/worker/batch_pipeline.py
src/worker/batch_pipeline_helpers/
    __init__.py
    error_details.py
```

1. Name the folder `{script_stem}_helpers`. The `_helpers` suffix keeps the folder from colliding with the script module of the same name.
2. Create the folder in the script's own directory. Add `__init__.py` so the main script can import it.
3. Put every helper that belongs to that script in this folder. Do not place those helpers in a shared `helpers/` directory, next to the script as loose files, or in another script's helper folder.
4. Inside the folder, keep a deep module with a simple interface. Do not add one file per function.
5. Leave helpers that already live in a shared `helpers/` directory where they are, unless the current task is already changing those helpers.

## File Size

- Keep the main script or component on orchestration/composition. Aim for under 200 lines.
- When a main Python script grows past that, move non-core work into its `{script_stem}_helpers/` folder. When a Next.js component grows past 200 lines, extract a focused child component or custom hook rather than a pass-through wrapper.
- A helper file may be longer than the main script. Split a helper past about 500 lines only when it mixes unrelated concerns.
- Do not split a file only to reduce its line count.

## What Stays In The Main File

Keep the entry point, the flow, and the calls that run that flow. Route handlers and task definitions stay in the main file when they only orchestrate.

Move parsing, formatting, validation, query building, file I/O, and error-message formatting into the helper folder or domain module.

## Contract-First Design

Define inputs, outputs, and behavior first (explicit type annotations, dataclasses/Pydantic models, TypeScript interfaces). Interact with modules through their public contract (black-box principle), keep one responsibility per module, and prefer dependency injection over hidden globals.

## How This Relates To Minimal Change

- **Minimal change** limits *what* you build (no extra features).
- **Modularity** governs *how* you structure the code you are already writing for the requested task.
- **Deep modules** govern module boundaries: few modules, simple interfaces, implementation hidden behind them.
- **Once and only once** means one implementation of a repeated behavior. Paths call it. They do not each carry their own copy.
- Do not invent unrequested features while modularizing.
- Do not refactor unrelated files solely for modularity or deeper modules unless the user asks.

## Policy Sync

This doc is the full statement of these rules. Agent entry files (`CLAUDE.md`, `AGENTS.md`, and `.cursor/rules/core-rules/agent-native-policy-always.mdc`) point here and stay in three-way sync.
