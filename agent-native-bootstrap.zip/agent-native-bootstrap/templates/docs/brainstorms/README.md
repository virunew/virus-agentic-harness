# Brainstorms

`ce-brainstorm` requirements files (`*-requirements.md`) live in this directory. `ce-plan` looks here for an origin document.
