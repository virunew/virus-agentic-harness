# Testing Structure And Organization

## TOC

- [Purpose](#purpose)
- [Command](#command)
- [Directory Layout](#directory-layout)
- [Naming Conventions](#naming-conventions)

## Purpose

Defines repository test layers, directory layout, and naming conventions.

## Command

Fast check: `{{TEST_COMMAND}}`.

The Stop hook runs this command when `.agent-native/test-command` exists and tracked files have changed.

## Directory Layout

Keep tests in the layout this repository already uses. When creating new test suites, separate them by layer:

```text
tests/
├── conftest.py
├── test_plan_beads_link.py
├── unit/
├── integration/
├── e2e/
├── regression/
└── fixtures/
```

| Layer | Purpose |
|-------|---------|
| `tests/unit/` | Fast isolated tests for pure functions, classes, hooks, and utilities |
| `tests/integration/` | Component interactions, API contracts, and test-database flows |
| `tests/e2e/` | Browser flows and live system checks |
| `tests/regression/` | Bug-reproduction tests written before fixing a reported defect |
| `tests/fixtures/` | Shared test data and fixtures |

## Naming Conventions

- Python: `test_<module>.py` for unit and integration tests; `test_<feature>_regression.py` for regression suites.
- TypeScript / Next.js: `<module>.test.ts(x)` for unit/integration tests; `<flow>.spec.ts` for Playwright E2E tests.
