# Agent Operating Policy Details

## TOC

- [Purpose](#purpose)
- [Standing Sandbox And Service Authorizations](#standing-sandbox-and-service-authorizations)
- [Project LLM Data Authorization](#project-llm-data-authorization)
- [Test Environment And TDD](#test-environment-and-tdd)
- [Live Verification](#live-verification)
- [Root-Cause Diagnosis](#root-cause-diagnosis)
- [User Confirmation Before Features](#user-confirmation-before-features)
- [User Communication And Context Framing](#user-communication-and-context-framing)
- [Change Review Communication](#change-review-communication)
- [Plan Scope And Modularity](#plan-scope-and-modularity)
- [ExecPlans And Adhoc Scripts](#execplans-and-adhoc-scripts)
- [Operational Reality And Observability](#operational-reality-and-observability)
- [Logging And Audit](#logging-and-audit)
- [Git, Branches, Worktrees, And Backups](#git-branches-worktrees-and-backups)
- [Escalation](#escalation)

## Purpose

Detailed operating rules for agent work that touches tests, runtime state, service verification, and user communication. Root policy files (`CLAUDE.md`, `AGENTS.md`, and `.cursor/rules/core-rules/agent-native-policy-always.mdc`) link here instead of repeating this full detail.

## Standing Sandbox And Service Authorizations

- **Diagnostic database reads (always authorized):** You are always authorized to reach outside the sandbox to read non-forbidden project databases when inspecting state or diagnosing issues. Do not stop to ask permission for those reads.
- **Configured test databases and services (always authorized):** You are always authorized to read and write configured test databases and test services. Never read or write the forbidden production resources listed in `docs/references/configuration-and-resources.md`: {{FORBIDDEN}}.
- **Local dev servers and browser verification (always authorized):** You are always authorized to start, stop, and query local development/test servers and browser verification tools (`localhost` / `127.0.0.1`) during development and live verification.

## Project LLM Data Authorization

The project owner grants standing authorization to send project data and test fixtures to the LLM providers configured for this project during development, testing, and live verification. Agents do not need to request per-call approval for these LLM requests. Keep API keys, tokens, and connection URLs out of prompt content and logs.

## Test Environment And TDD

- Fast check command: `{{TEST_COMMAND}}`.
- Never run tests against forbidden production resources ({{FORBIDDEN}}). Always load the test environment first.
- **Strict TDD is mandatory** for all development work: new features, bug fixes, and refactoring.
- Follow red -> green -> refactor: write the failing test first, implement the minimum code to pass, then clean up while tests stay green.

Required test layers:

| Layer | When | Location |
|-------|------|----------|
| Unit tests | Always, for pure functions, classes, hooks, and utilities | `tests/unit/` |
| Integration tests | Always, for component interactions, API contracts, and database flows | `tests/integration/` |
| Live/E2E tests | Browser automation, UI flows, and third-party platform integrations | `tests/e2e/` |
| Regression tests | Every bug fix (must fail before the fix and pass after) | `tests/regression/` or alongside the affected suite |

Change-specific requirements:

- Bug fixes require a failing regression test that reproduces the bug before the fix.
- Database changes require integration tests against configured test databases; never use production data.
- Third-party integrations require a live smoke test against the third-party platform before completion.

## Live Verification

Do not claim completion without live verification of affected behavior against test resources:

1. Confirm configured resources point at test instances, never production.
2. **Backend/API changes:** Start the real service against test resources and exercise the affected endpoints. Restart the service after code changes before re-testing. Do not call mocked route handlers or in-memory substitutes "live verification."
3. **Frontend/UI changes:** Start the dev server, exercise the changed flows in the browser, and take screenshots at mobile `375x812` and desktop `1200x800` viewports.
4. Report the environment used and what was verified.

## Root-Cause Diagnosis

For bugs, incidents, regressions, or unexpected behavior:

1. Identify the first bad step in the causal chain.
2. Distinguish root cause from downstream effects.
3. Verify which component or decision introduced the problem.
4. Fix the root cause.
5. Add mitigation only when necessary.
6. Describe any symptom-only action explicitly as temporary.

A symptom fix that leaves the causal source unknown is not a completed diagnosis.

Before significant implementation, bug fixes, or architectural decisions, search `docs/solutions/` for past incidents, fixes, and patterns using `rg` or `learnings-researcher`.

## User Confirmation Before Features

Never add new features, unrequested edge cases, fallback mechanisms, retry/caching layers, extra validation, or helper utilities beyond the minimal fix without explicit user confirmation:

1. Identify the minimal change needed for the requested outcome.
2. If you notice an extra edge case or improvement beyond that scope, stop and ask the user before implementing it.
3. **Always ask before planning backward compatibility** — shims, dual code paths, and migration layers add complexity and require explicit user approval.

## User Communication And Context Framing

- **Plain language:** Explain work in clear, non-cryptic terms. When a technical term is needed, briefly define what it means on first use in that reply.
- **Context framing (mandatory):** Every status, blocker, or findings message must open with **short, crisp context** (2–5 sentences stating what we are checking, which plans/systems apply, and what "good" vs "blocked" means here) before any counts, tables, or plan IDs.

## Change Review Communication

When delivering completed work, explain all changes for effective review:

- State **why** each change was made, not only what changed.
- Include **code snippets** or file/line citations for meaningful diffs.
- Call out trade-offs, assumptions, and alternatives considered when relevant.
- Summarize automated test and live verification evidence alongside the explanation.

## Plan Scope And Modularity

Follow `docs/architecture/planning-scope-and-modularity.md` for one goal per plan, `{script_stem}_helpers/` folders, deep modules, once and only once, and file size.

## ExecPlans And Adhoc Scripts

- Every new ExecPlan needs a unique three-digit plan ID in `docs/plans/YYYY-MM-DD-NNN-<slug>-plan.md`; state `Plan ID: NNN` and `Beads epic: {{PREFIX}}-...` at the top.
- Plan-implementing one-time scripts go in `scripts/adhoc/NNN-<descriptive-slug>.*`.
- Other one-time scripts go in `scripts/adhoc/<descriptive-slug>.*` without a plan prefix.
- Full conventions: `docs/references/execplans-and-adhoc-scripts.md`.

## Operational Reality And Observability

When a change touches live operational state, verify the real runtime context before changing code:

- Process manager.
- Environment injection.
- File ownership.
- Mutation paths.
- Runtime state files.

Until those facts are checked, code-only assumptions are speculative.

## Logging And Audit

A developer or a later agent must be able to reconstruct a run from the logs without a debugger. This applies to every path you add or change that calls an external system, reads or writes data, skips, retries, or fails.

Use `logging.getLogger(__name__)` in Python (or the project's existing logger). Write logs under `logs/` with log rotation for long-running processes. Do not add a new logging framework or a second audit store.

Each log line names the operation and the domain identifiers that locate it (entity id, file, or batch id).

| Level | Use |
|-------|-----|
| INFO | A completed action, or a decision that changes the outcome |
| WARNING | A skip, or a failure that does not stop the rest of the run |
| ERROR | This unit of work failed. Include the exception and the input that caused it |
| DEBUG | High-volume detail |

Do not log secrets, connection URLs, API keys, tokens, or full document bodies.

## Git, Branches, Worktrees, And Backups

- Stay on the current branch and current worktree by default. Never create, switch to, or initialize a branch or worktree unless the user explicitly asks for it or approves it first for the current task. If isolation would help, explain why and ask first.
- Do not commit, push, or sync Beads (`bd dolt push`) unless the user asks or the active repository profile grants authority.
- Git history is the source of truth and backup. Do not create `_old`, `_backup`, `TODO` placeholders, or commented-out code as substitutes for history.
- When an ExecPlan or major feature is completed, create a local annotated git tag (`git tag -a plan-NNN-<slug> -m "..."` or `git tag -a feature-<slug> -m "..."`). Do not push tags to remote unless asked.

## Escalation

Escalate before proceeding when:

- Adding or reducing backward compatibility without user approval.
- Adding features or edge cases beyond the minimal fix.
- Changing the core architectural approach.
- Confidence is below about 90% for an architectural decision; use `grill-me` before proceeding.
- External review comments arrive; run `vet-reviews` before implementing them.
