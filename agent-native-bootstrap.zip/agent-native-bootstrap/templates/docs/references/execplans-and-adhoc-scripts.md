# ExecPlans and adhoc scripts

## TOC

- [Plans](#plans)
- [Beads link](#beads-link)
- [Scripts](#scripts)

## Plans

See `PLANS.md` at the repository root.

Filename: `docs/plans/YYYY-MM-DD-NNN-<slug>-plan.md`.

`NNN` is unique in this tree. Search `completed/` and `archive/` before choosing the next number.

## Beads link

An unfinished plan has these two lines:

```text
Plan ID: NNN
Beads epic: {{PREFIX}}-...
```

The epic label is `plan-NNN`. Its `spec_id` is the plan path relative to this repository. One epic per plan id.

`python3 scripts/plan_beads_link.py` exits 0 when the link holds and no `Plan ID:` repeats. It exits non-zero otherwise.

## Scripts

Plan scripts: `scripts/adhoc/NNN-<slug>.*`.

Other one-time scripts: `scripts/adhoc/<slug>.*`.

Reusable code stays in the application tree.
