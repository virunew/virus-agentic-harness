# Agent Skill Map

## TOC

- [Purpose](#purpose)
- [Which Skill When](#which-skill-when)
- [What Stays Out Of The Repo](#what-stays-out-of-the-repo)

## Purpose

Claude Code, Codex, and Cursor use the same workflow skills in this repository. This page maps each engineering situation to the skill to invoke and the directory where its artifact belongs. Domain terms live in `docs/references/CONCEPTS.md`.

## Which Skill When

| When | Skill | Where the result goes |
|---|---|---|
| Ambiguous feature, before any plan | `ce-brainstorm` | `docs/brainstorms/*-requirements.md` |
| Stress-test a design or reach >=90% confidence | `grill-me` | `Decision Log` of the ExecPlan after reading `docs/{plans,solutions,architecture,references,critical}/` |
| Multi-step implementation | `ce-plan`, then a Beads epic `{{PREFIX}}-...` | `docs/plans/YYYY-MM-DD-NNN-<slug>-plan.md` |
| Implement an ExecPlan | `ce-work` | Code + tests, then `python3 scripts/plan_beads_link.py` |
| Review or tighten a plan or spec | `ce-doc-review` | The reviewed document |
| Review code changes | `ce-code-review` | Review findings and fixes |
| External reviewer comments arrive | `vet-reviews` | Verify each claim against the codebase before changing code |
| Bug with an unknown root cause | `ce-debug` | Failing test first, then minimal root-cause fix |
| Before a significant change | `learnings-researcher` | Search `docs/solutions/` (always check `docs/solutions/patterns/critical-patterns.md`) |
| Document a solved, non-obvious incident | `ce-compound` | `docs/solutions/<category>/` with YAML frontmatter |
| Next.js / React performance work | `vercel-react-best-practices` | Applied in impact order (waterfalls and bundle size before micro-optimizations) |
| Architecture / file relationship query | `graphify` (when `graphify-out/` exists) | `graphify query "<question>" --budget 5000`, then `Read`/`Grep` on the named files |

## What Stays Out Of The Repo

Workflow skills (`ce-*`, `grill-me`, `vet-reviews`, `learnings-researcher`, `graphify`) are user-level skills. Do not copy them into `.agents/skills/`. The repo-local skills are `.agents/skills/beads/SKILL.md` and (for Next.js) `.agents/skills/vercel-react-best-practices/SKILL.md`.
