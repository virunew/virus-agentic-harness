# Configuration And Resources

## TOC

- [Explicit Configuration](#explicit-configuration)
- [Forbidden Production Resources](#forbidden-production-resources)
- [Authorized Test And Local Resources](#authorized-test-and-local-resources)

## Explicit Configuration

List every required environment variable here. The process must validate required configuration at startup and fail fast with a clear error when a required variable or resource is missing. Never silently fall back to `localhost`, a default database name, a public model endpoint, or an alternate service. Ask the user before adding any fallback mechanism.

## Forbidden Production Resources

Production resources the agent must not read or write during tests or verification:

{{FORBIDDEN}}

## Authorized Test And Local Resources

- Diagnostic database reads for inspection, configured test databases (read/write), configured LLM endpoints during development/testing, and local dev servers/browser verification tools (`localhost`) are authorized without per-call prompts.
- Never commit `.env` files, credentials, tokens, or local database files (`.db`, `.sqlite`, `.sqlite3`).
