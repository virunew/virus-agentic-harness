# Project Concepts And Vocabulary

## TOC

- [Purpose](#purpose)
- [Workflow Terms](#workflow-terms)
- [Domain Terms](#domain-terms)

## Purpose

Defines shared terms used across plans, issues, and documentation so agents and humans use one name for each concept.

## Workflow Terms

- **ExecPlan**: A self-contained, living execution plan under `docs/plans/YYYY-MM-DD-NNN-<slug>-plan.md` governed by `PLANS.md`.
- **Plan ID (`NNN`)**: A three-digit identifier (`001`–`999`) unique across every `docs/plans/` tree in the repository.
- **Beads (`bd`)**: The repository's issue tracker. Every unfinished ExecPlan links to one Beads epic (`{{PREFIX}}-...`) carrying label `plan-NNN` and `spec_id` equal to the plan's repo-relative path.
- **Fast check**: The quick verification command in `.agent-native/test-command` run by the `Stop` hook when code changes.
- **Deep module**: A module that hides substantial implementation behind a small, simple public interface (see `docs/architecture/planning-scope-and-modularity.md`).

## Domain Terms

Add project-specific domain entities, invariants, and external service names here as the codebase grows.
