---
title: Critical patterns
date: {{DATE}}
module: repository
problem_type: best_practice
component: development_workflow
severity: critical
tags: [critical-patterns, tests, production]
---

# Critical patterns

## TOC

- [Safe check](#safe-check)
- [Production](#production)

## Safe check

The fast verification command is `{{TEST_COMMAND}}`.

## Production

Do not use these resources for tests or live verification:

{{FORBIDDEN}}
