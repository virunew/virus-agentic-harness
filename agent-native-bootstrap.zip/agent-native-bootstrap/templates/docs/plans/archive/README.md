# Archived plans

Abandoned plans live in this directory. They are outside the unfinished-plan check. Their plan ids stay retired.
