# Critical rules

## TOC

- [Rules](#rules)

## Rules

- Production resources listed in `docs/solutions/patterns/critical-patterns.md` are out of bounds.
- Required configuration fails when it is missing. There is no silent default host or database.
- Work is tracked in Beads. There is no second task list.
- Plans follow `PLANS.md`.
- One behavior has one implementation. Do not copy it into a second path as part of an unrelated change.
